from random import *
from math import *
import pygame
pygame.init()
win=pygame.display.set_mode((1800,900))
run=True
F=lambda :randint(0,1)*2-1
dimcount=4
pos=[0 for i in range(dimcount)]
POI=[[F()*randint(1,600) for i in range(dimcount)] for i in range(4)]
fonts={}
texts={}
def produce(text="NOT FOUND",size=10,color=(255,255,255),font="courier new"):
    font_key=str(font)+str(int(size))
    text_key=font_key+str(text)+str(color)
    if not font_key in fonts:
        fonts[font_key]=pygame.font.SysFont(str(font),int(size))
    if not text_key in texts:
        texts[text_key]=fonts[font_key].render(str(text),1,color)
    return texts[text_key]
def center(sprite,surface,x,y):
    surface.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))
def romanify(number):
    _romanify=["IXCM","VLD"]
    output="M"*(number//1000); number%=1000
    for i in range(3):
        if number>=9*10**(2-i):  output+=_romanify[0][2-i]+_romanify[0][3-i]; number -=9*10**(2-i)
        if number>=5*10**(2-i):  output+=_romanify[1][2-i];  number -=5*10**(2-i)
        if number>=4*10**(2-i):  output+=_romanify[0][2-i]+_romanify[1][2-i]; number -=4*10**(2-i)
        output+=_romanify[0][2-i]*(number//(10**(2-i))); number%=10**(2-i)
    return output
def cO(d1,d2): #converts POI to visible data
    output=[]
    for i in POI:
        #Absolute center pos is the projection of d1 and d2 on 
        for ii in range(10):
            hypotenuse=(ii+1)*(ii+2)*5
            catete=dist([pos[iii] for iii in range(dimcount) if not iii in [d1,d2]],[i[iii] for iii in range(dimcount) if not iii in [d1,d2]])
            if hypotenuse>=catete:
                output.append([[i[iii] for iii in range(dimcount) if iii in [d1,d2]],int(sqrt(hypotenuse**2-catete**2)),ii])
    return output
PSD=0
SSD=1
renders=cO(PSD,SSD)
r2=cO(2,3)
camera_x=-900
camera_y=-450

keys=pygame.key.get_pressed()
while run:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if event.type==pygame.KEYDOWN and False:
            if event.key==pygame.K_i:
                PSD+=1
                if PSD==SSD: PSD+=1
                if PSD==dimcount: PSD=0
                if PSD==SSD: PSD+=1
                renders=cO(PSD,SSD)
            if event.key==pygame.K_o:
                SSD+=1
                if SSD==PSD: SSD+=1
                if SSD==dimcount: SSD=0
                if SSD==PSD: SSD+=1
                renders=cO(PSD,SSD)
    win.fill((0,0,0))
    mouse_down=pygame.mouse.get_pressed()
    mouse_rel=pygame.mouse.get_rel()
    keys=pygame.key.get_pressed()
    ppos=pos.copy()
    if keys[pygame.K_UP]: pos[SSD]-=1
    if keys[pygame.K_DOWN]: pos[SSD]+=1
    if keys[pygame.K_LEFT]: pos[PSD]-=1
    if keys[pygame.K_RIGHT]: pos[PSD]+=1

    if keys[pygame.K_w]: pos[3]-=1
    if keys[pygame.K_s]: pos[3]+=1
    if keys[pygame.K_a]: pos[2]-=1
    if keys[pygame.K_d]: pos[2]+=1
    
    if ppos!=pos:
        r2=cO(2,3)
        renders=cO(PSD,SSD)
    if mouse_down[0]:
        camera_x-=mouse_rel[0]
        camera_y-=mouse_rel[1]
    for i in r2:
        pygame.draw.circle(win,(0,155-15*i[2],155-15*i[2]),(i[0][0]-camera_x,i[0][1]-camera_y),i[1],2)
    for i in renders:
        pygame.draw.circle(win,(255-25*i[2],255-25*i[2],255-25*i[2]),(i[0][0]-camera_x,i[0][1]-camera_y),i[1],2)
    pygame.draw.circle(win,(255,0,0),(pos[PSD]-camera_x,pos[SSD]-camera_y),10,5)
    pygame.draw.circle(win,(255,255,0),(pos[2]-camera_x,pos[3]-camera_y),10,5)

    center(produce(romanify(PSD+1),23),win,1760,15)
    center(produce(romanify(SSD+1),23),win,30,860)
    
    pygame.display.update()
pygame.quit()
