from kscript import *
from kscript.A.Button import *
import os
import json
debug_mode=0

Map_Surface=pygame.Surface((900,900))
end_turn_button=Button("End Turn",20,(25,25,25))
deselect_button=Button("Deselect",20,(25,25,25))
attack_target_overlay=pygame.Surface((100,100))
attack_target_overlay.set_alpha(60)
attack_target_overlay.set_colorkey((0,0,0))
pygame.draw.circle(attack_target_overlay,(255,0,0),(50,50),20,10)
#Imports Minion Data
minion_data={}
for root,dirs,files in os.walk(r"Resources\\Minions\\"):
    for file in files:
        if file.endswith(".json"):
            with open(os.path.join(root,file),"r") as f:
                minion_data[file[:-5]]=json.loads(f.read())
#Imports Minion Data
map_data={}
for root,dirs,files in os.walk(r"Resources\\Maps\\"):
    for file in files:
        if file.endswith(".json"):
            with open(os.path.join(root,file),"r") as f:
                map_data[file[:-5]]=json.loads(f.read())
#Sewers have a max of 3 combatants
current_team=0
player_count=2
class Active_Combatant: 
    def __init__(self,tips,mymap,team=1):
        self.tips=tips
        
        self.map=mymap
        self.space_id=choice(self.map.empty_spawn_points[team])
        self.map.empty_spawn_points[team].remove(self.space_id)
        self.update_space()
        self.team=team
        self.data=minion_data[tips].copy()
        self.alive=True
        self.movement_left=0

        #Time TO MISh MASH The STATS
        
        self.actions=self.data["Actions"]
        if "Counters" in self.data: self.counters=self.data["Counters"].copy()
        else: self.counters={}
        if "SOT Actions" in self.data: self.SOT_actions=self.data["SOT Actions"].copy() #Abilities that trigger at the start of each turn
        else: self.SOT_actions={}

        self.stats={
            "Max Health": self.data["health"],
            "Health": self.data["health"],
            "Max Speed": self.data["speed"],
            "Speed": self.data["speed"],
            "Max Stamina": self.data["Stamina"],
            "Stamina": self.data["Stamina"],
            "Defense":0,
        }
        for i in self.counters:
            self.stats[i]=self.counters[i]
        

        self.sprite=pygame.transform.scale(pygame.image.load(self.data["sprite"]),(100,100))
       # self.sprite.set_colorkey((255,255,255))
        self.start_turn(True)
        if self.team>player_count:
            #The First one is how offensive this creature is, A larger value means it is more likely to move towards enemies, while a lower value means he is more likely to run away
            self.AI=[random()]
    def update_space(self):
        self.space=self.map.spaces[str(self.space_id)]
        self.map.spaces[str(self.space_id)]["Occupied"]=self
    def start_turn(self,initial=False):
        self.stats["Speed"]=self.stats["Max Speed"]
        self.stats["Stamina"]=self.stats["Max Stamina"]
        if not initial:
            for i in self.SOT_actions:
                self.use_action(i,self)
            print(self.stats)
    def draw(self):
        global selected_combatant,displaying_action
        if self.alive:
            if self.stats["Health"]>self.stats["Max Health"]:
                self.stats["Health"]=self.stats["Max Health"]
            if abs(self.space["Display"]["x"]*self.map.space_distance-map_camera_x-mouse_pos[0])<50 and abs(self.space["Display"]["y"]*self.map.space_distance-map_camera_y-mouse_pos[1])<50:
                if click[0] and self.team==current_team and displaying_action==None:
                    selected_combatant=self
            sprite_x=self.space["Display"]["x"]*self.map.space_distance-map_camera_x-50
            sprite_y=self.space["Display"]["y"]*self.map.space_distance-map_camera_y-50
            Map_Surface.blit(self.sprite,(sprite_x,sprite_y))
            if self.team!=current_team:
                pygame.draw.rect(Map_Surface,(85,0,0),(sprite_x,sprite_y-10,100,10))
                pygame.draw.rect(Map_Surface,(0,255,0),(sprite_x,sprite_y-10,100*self.stats["Health"]/self.stats["Max Health"],10))
                center(render_text(self.data["Display Name"],15,(255,255,255),"comicsansms"),Map_Surface,sprite_x+50,sprite_y-20)
    def check_if_action_is_possible(self,input_action=None):
        action_possible=True
        if input_action==None:
            input_action=displaying_action
        if "Cost" in input_action:
            for ii in input_action["Cost"]:
                if not ii in self.stats:
                    self.stats[ii]=0
                if self.stats[ii]<input_action["Cost"][ii]:
                    action_possible=False
        return action_possible
    def use_action(self,action,target):
        if self.check_if_action_is_possible(action):
            #self.stats["Stamina"]-=displaying_action["Stamina Cost"]
            if "Cost" in action:
                for ii in action["Cost"]:
                    self.stats[ii]-=action["Cost"][ii]
            if action["Type"]=="Attack":
                target.lose_hp(action["Damage"])
            if action["Type"]=="Buff":
                for iii in action["Buffs"]:
                    if iii["Type"]=="Speed":
                        target.stats["Speed"]+=iii["Ammount"]
                    if iii["Type"]=="Health":
                        target.stats["Health"]+=iii["Ammount"]
                        target.stats["Health"]=min(target.stats["Health"],target.stats["Max Health"])
                        if target.stats["Health"]<=0 and target!=self:
                            target.die()
            if action["Type"]=="Grand Action":
                for new_action in action["Lines"]:
                    print(new_action)
                    self.use_action(new_action,target)
            if action["Type"]=="Modify Stat":
                if not action["Stat"] in target.stats:
                    target.stats[action["Stat"]]=0
                if action["Sign"]=="+":
                    target.stats[action["Stat"]]+=action["Value"]
            if action["Type"]=="Random":
                if random()<action["Chance"]:
                    self.use_action(action["Line"],target)
    def display_data(self):
        global displaying_action
        if self.alive:
            win.blit(render_text(self.data["Display Name"],25,(120,0,240),"comicsansms"),(1402,1))
            sprite=render_text(f"Health:{self.stats["Health"]}",25,(120,0,240),"comicsansms")
            win.blit(sprite,(1795-sprite.get_width(),1))
            win.blit(render_text(f"Moves Left: {self.stats["Speed"]}",25,(120,0,240),"comicsansms"),(1402,25))
            if self.team==current_team:
                win.blit(render_text(f"friendly",25,(120,0,240),"comicsansms"),(1402,49))     
                for i in self.space["Distance"]:
                    if displaying_action==None:
                        if i<=self.stats["Speed"] and i>0:
                            for ii in self.space["Distance"][i]:
                                if self.map.spaces[ii]["Occupied"]==None:
                                    alpha_x=self.map.spaces[ii]["Display"]["x"]*self.map.space_distance-map_camera_x
                                    alpha_y=self.map.spaces[ii]["Display"]["y"]*self.map.space_distance-map_camera_y
                                    pygame.draw.circle(Map_Surface,(0,125,255),(alpha_x,alpha_y),45,10)
                                    pygame.draw.circle(Map_Surface,(0,125,255),(alpha_x,alpha_y),15)
                                    if abs(mouse_pos[0]-alpha_x)<50 and abs(mouse_pos[1]-alpha_y)<50 and click[0]:
                                        self.move_to(ii)
                                        self.stats["Speed"]-=i
                    else:
                        if deselect_button.display(Map_Surface,800,40,mouse_pos,click): displaying_action=None
                        elif displaying_action["Type"]=="Targeted Action":
                            for ii in self.space["Distance"][i]:
                                if self.map.spaces[ii]["Occupied"]!=None:
                                    Target=self.map.spaces[ii]["Occupied"]
                                    action_possible=True
                                    if "Min Range" in displaying_action:
                                        if i<displaying_action["Min Range"]:
                                            action_possible=False
                                    if displaying_action["Range"]>=i and action_possible:
                                        alpha_x=self.map.spaces[ii]["Display"]["x"]*self.map.space_distance-map_camera_x
                                        alpha_y=self.map.spaces[ii]["Display"]["y"]*self.map.space_distance-map_camera_y
                                        pygame.draw.circle(Map_Surface,displaying_action["Target Color"],(alpha_x,alpha_y),45,10)
                                        pygame.draw.circle(Map_Surface,displaying_action["Target Color"],(alpha_x,alpha_y),15)
                                        if abs(mouse_pos[0]-alpha_x)<50 and abs(mouse_pos[1]-alpha_y)<50 and click[0]:
                                            for new_action in displaying_action["Lines"]:
                                                self.use_action(new_action,Target)
                                            if "Cost" in displaying_action:
                                                for ii in displaying_action["Cost"]:
                                                    self.stats[ii]-=displaying_action["Cost"][ii]
                                            displaying_action=None
                                if displaying_action==None:
                                    break
                        else:
                            self.use_action(displaying_action,self)
                            displaying_action=None
                            
                                                    
                        #if click[0]:
                        #    displaying_attack=None
            
            for i in enumerate(self.actions):
                if self.check_if_action_is_possible(self.actions[i[1]]):
                    if display_button(text=i[1],bpc=(120,0,240),surface=win,x=1600,y=120+i[0]*60,mouse_pos=mouse_pos,click=click):
                        displaying_action=self.actions[i[1]]
                else:
                    display_button(text=i[1],bpc=(120,120,120),surface=win,x=1600,y=120+i[0]*60,mouse_pos=mouse_pos,click=click)
            if debug_mode==2 and displaying_action!=None:
                center(render_text(displaying_action["Type"],color=(255,0,0)),Map_Surface,450,450)
            if max(self.stats["Max Stamina"],self.stats["Stamina"])>10:
                center(render_text(f"Stamina: {self.stats["Stamina"]}/{self.stats["Max Stamina"]}",15,color=(90,0,180),font="comicsansms"),win,1600,160+i[0]*60)
            else:
                for ii in range(self.stats["Max Stamina"]):
                    ii_=(ii-(self.stats["Max Stamina"]-1)/2)*30
                    pygame.draw.circle(win,(60,0,120),(1600+ii_,160+i[0]*60),10,3)
                for ii in range(self.stats["Stamina"]):
                    ii_=(ii-(self.stats["Max Stamina"]-1)/2)*30
                    if displaying_action!=None and "Stamina" in displaying_action["Cost"] and displaying_action["Cost"]["Stamina"]>=self.stats["Stamina"]-ii:
                        pygame.draw.circle(win,(0,120,240),(1600+ii_,160+i[0]*60),5)
                    else:
                        pygame.draw.circle(win,(120,0,240),(1600+ii_,160+i[0]*60),5)
            if self.stats["Health"]<=0:
                self.die()
            elif self.stats["Health"]>self.stats["Max Health"]:
                self.stats["Health"]=self.stats["Max Health"]
    def move_to(self,target_square):
        self.space["Occupied"]=None
        self.space_id=target_square
        self.update_space()
    def lose_hp(self,ammount):
        self.stats["Health"]-=max(0,ammount-self.stats["Defense"])
        if self.stats["Health"]<=0:
            self.die()
            self.stats["Health"]=0
    def die(self):
        self.alive=False
        self.space["Occupied"]=None
        self.space=None
class Map:
    def __init__(self,pool):
        self.data=map_data[choice(pool)].copy()
        self.spaces=self.data["Spaces"]
        self.paths=self.data["Paths"]
        self.empty_spawn_points=[[],[]]
        for i in self.spaces:
            self.spaces[i]["Occupied"]=None
            if "Tags" in self.spaces[i]:
                tested=self.spaces[i]["Tags"]
                if "GoodSpawnPoint" in tested:
                    self.empty_spawn_points[0].append(i)
                if "EvilSpawnPoint" in tested:
                    self.empty_spawn_points[1].append(i)
            self.spaces[i]["Paths Out"]=[]
        for i in self.paths:
            if not "Color" in i:
                i["Color"]=[255,255,255]
            self.spaces[i["Alpha"]]["Paths Out"].append([i["Beta"],i["Travel_Cost_Alpha"]])
            self.spaces[i["Beta"]]["Paths Out"].append([i["Alpha"],i["Travel_Cost_Beta"]])
            
        self.space_distance=self.data["Space Distance"]*100
        self.selected_square=None
        for i in self.spaces:
            self.spaces[i]["Distance"]=self.calculate_distance_from_space(i)
    def draw_connects(self):
        for i in self.paths: #Draws the paths between spaces
            alpha_x=self.spaces[str(i["Alpha"])]["Display"]["x"]*self.space_distance-map_camera_x
            alpha_y=self.spaces[str(i["Alpha"])]["Display"]["y"]*self.space_distance-map_camera_y
            beta_x=self.spaces[str(i["Beta"])]["Display"]["x"]*self.space_distance-map_camera_x
            beta_y=self.spaces[str(i["Beta"])]["Display"]["y"]*self.space_distance-map_camera_y
            alpha_movement_cost=i["Travel_Cost_Alpha"]
            beta_movement_cost=i["Travel_Cost_Beta"]
            pygame.draw.line(Map_Surface,i["Color"],(alpha_x,alpha_y),(beta_x,beta_y))
        for i in self.spaces: #Draws the spaces themselves
            space_x=self.spaces[i]["Display"]["x"]*self.space_distance-50-map_camera_x
            space_y=self.spaces[i]["Display"]["y"]*self.space_distance-50-map_camera_y
            if abs(mouse_pos[0]-space_x-50)<50 and abs(mouse_pos[1]-space_y-50)<50:
                pygame.draw.rect(Map_Surface,(255,255,0),(space_x,space_y,100,100))
                self.selected_square=i #Selects the last hovered over square
            elif i==self.selected_square:
                pygame.draw.rect(Map_Surface,(255,125,0),(space_x,space_y,100,100))  #Orange display square
            else:
                pygame.draw.rect(Map_Surface,(255,255,255),(space_x,space_y,100,100)) #Another Square
            if debug_mode==1:
                center(render_text(i,30,(0,0,0),"comicsansms"),Map_Surface,space_x+50,space_y+50)
    def calculate_distance_from_space(self,space):
        #I was half drunk on pepsi while writing this, so i have no idea how this even works, but it does. 
        distances={}
        checked_squares=[]
        unchecked_squares=[[space,0]]
        us_id=[space]
        #List all paths, Sort them by length, then run from start
        while len(checked_squares)<len(self.spaces):
            currently_checking_square=unchecked_squares[0]
            for i in self.spaces[currently_checking_square[0]]["Paths Out"]:
                if not i[0] in us_id:
                    unchecked_squares.append([i[0],i[1]+currently_checking_square[1]])
                    us_id.append(i[0])
                elif i[0] in us_id:
                    for ii in unchecked_squares:
                        if ii[0]==i[0]:
                            if i[1]+currently_checking_square[1]<ii[1]:
                                ii[1]=currently_checking_square[1]+i[1]
            checked_squares.append(currently_checking_square)
            unchecked_squares.pop(0)
        for i in checked_squares:
            if not i[1] in distances:
                distances[i[1]]=[]
            distances[i[1]].append(i[0])
        return distances
m=Map(["Sewers1"])
player_teams=[
    [
        "wizard rat",
        "rat",
        "snail"
    ],
    [
        "doctor4t",
        "doctor4t",
        "wizard rat"
    ]
]
combatant_array=[Active_Combatant(player_teams[i//3][i%3],m,i//3) for i in range(6)]
map_camera_x=-450
map_camera_y=-450
dragging_map=False
selected_combatant=None
displaying_action=None
current_turn=1
for i in combatant_array:
    if current_team==i.team:
        i.start_turn()
while run:
    Map_Surface.fill((0,0,0))
    pygame.draw.rect(Map_Surface,(25,25,25),(0,0,900,900),2)
    pygame.draw.rect(win,(15,0,30),(1400,0,400,900))
    pygame.draw.rect(win,(120,0,240),(1400,0,400,900),2)
    pygame.draw.rect(win,(15,0,30),(900,700,500,200))
    pygame.draw.rect(win,(120,0,240),(900,700,500,200),2)

    exec(getevent())
    if keys[27]: run=False
    #Adjusts the camera position
    m.draw_connects()
    for i in combatant_array:
        i.draw()
    if mouse_down[0] and mouse_pos[0]<900:
        dragging_map=True
    if dragging_map: 
        map_camera_x-=mouse_rel[0]
        map_camera_y-=mouse_rel[1]
        if not mouse_down[0]:
            dragging_map=False
    if selected_combatant!=None:
        selected_combatant.display_data()
    center(render_text(f"Turn {current_turn}",font="comicsansms"),Map_Surface,800,820)
    if end_turn_button.display(Map_Surface,800,860,mouse_pos,click): 
        current_team=(current_team+1)%player_count
        for i in combatant_array:
            if i.team==current_team:
                #print(i.team,current_team,i.data["Display Name"])
                i.start_turn()
        current_turn+=1
        displaying_action=None

    win.blit(Map_Surface,(0,0))
    endframe()
pygame.quit()
