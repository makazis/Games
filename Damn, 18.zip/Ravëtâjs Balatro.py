from random import *
from math import *
import pygame
pygame.init()
win=pygame.display.set_mode((1200,600))
run=True
# Dice Explanation:
# 0: Type of dice
# 1: Name of attack
# 2: Data
# Types of dice:
# 0: Deal damage to target creature
#  Data:
#   "Damage":(INT) Ammount Of Damage dealt
#
# 1: Restore health to target creature
#
#
#
#
#
#
#
#
#
#
class Creature:
    def __init__(self,tips=None):
        if tips==None:
            self.dice=[]
            self.hp=1
            self.max_hp=1
        elif tips=="Goblin":
            self.max_hp=4+randint(0,randint(0,3))
            self.dice=[
                    [[0,"Knife Stab",{"Damage":1+int(randint(0,4)==0)}]],
                    [[0,""]],
                    [[]],
                    [[]]
                ]
while run:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    win.fill((0,0,0))
    pygame.display.update()
pygame.quit()
