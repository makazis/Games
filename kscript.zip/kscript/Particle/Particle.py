import pygame
from math import *
from random import *
from kscript import render_text,center
#0 is a spinning triangle
#1 is a flying text
#2 is an expanding bubble
class Particle:
    def __init__(self,pos,tips=0,**kwargs):
        self.x=pos[0]
        self.y=pos[1]
        self.tips=tips
        if "primary_color" in kwargs:   self.primary_color=kwargs["primary_color"]
        else:                           self.primary_color=(255,255,255)
        if "secondary_color" in kwargs: self.secondary_color=kwargs["secondary_color"]
        else:                           self.secondary_color=(0,0,0)
        if "delta" in kwargs:           self.delta=kwargs["delta"]
        else:                           self.delta=pi/2
        if "d_theta" in kwargs:         self.d_theta=kwargs["d_theta"]
        else:                           self.d_theta=tau/100
        if "side_count" in kwargs:      self.side_count=kwargs["side_count"]
        else:                           self.side_count=3
        if "time" in kwargs:            self.time=kwargs["time"]
        else:                           self.time=1
        if "speed" in kwargs:           self.speed=kwargs["speed"]
        else:                           self.speed=0
        if "size" in kwargs:            self.size=kwargs["size"]
        else:                           self.size=4
        if "size_affected" in kwargs:   self.sabt=True
        else:                           self.sabt=False 
        if "width" in kwargs:           self.width=kwargs["width"]
        else:                           self.width=0
        if "text" in kwargs:            self.text=kwargs["text"]
        else:                           self.text=choice(list("qwertyuiopasdfghjklzxcvbnm1234567890-=[];'\,./"))
        if "affected_gravity" in kwargs:self.affected_by_gravity=kwargs["affected_gravity"]
        else:                           self.affected_by_gravity=False
        if "debug" in kwargs:           self.debug=kwargs["debug"]
        else:                           self.debug=False
        if self.debug:
            print(self.x,self.y,self.text,self.size,self.primary_color)
        self.time_left=self.time
        if self.tips in [0,2]: self.theta=random()*tau
        if self.tips in [0,1,2]: self.xspeed=cos(self.delta)*self.speed; self.yspeed=sin(self.delta)*self.speed
    def draw(self,surface,delta_time):
        
        if self.time_left>0:
            if self.tips==0:
                self.time_left-=delta_time
                self.theta+=self.d_theta
                self.age=self.time_left/self.time
                self.x+=self.xspeed
                self.y+=self.yspeed
                #print([self.primary_color[i]*self.age+self.secondary_color[i]*(1-self.age) for i in range(3)])
                pygame.draw.polygon(surface,
                                    [max(0,min(255,self.primary_color[i]*self.age+self.secondary_color[i]*(1-self.age))) for i in range(3)],
                                    [[self.x+cos(tau/self.side_count*i+self.theta)*self.size*(1-int(self.sabt)*(1-self.age)),
                                    self.y+sin(tau/self.side_count*i+self.theta)*self.size*(1-int(self.sabt)*(1-self.age))
                                    ] for i in range(self.side_count)],
                                    self.width)
            elif self.tips==1:
                self.time_left-=delta_time
                self.xspeed*=0.989**delta_time
                self.yspeed+=0.1*delta_time
                self.x+=self.xspeed
                self.y+=self.yspeed
                center(render_text(self.text,self.size,self.primary_color,bold=True),surface,self.x,self.y)
            #elif self.tips==2:
            return False
        else:
            return True