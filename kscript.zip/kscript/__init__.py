from random import *
from math import *
import pygame
from kscript.KeyDef import *
pygame.init()
screen=pygame.display.set_mode((0,0))
win=pygame.Surface((1800,900))
size_offset=[screen.get_width()/1800,screen.get_height()/900]
run=True
click=[False for i in range(3)]
ctimer=[0,0,0]
clock=pygame.time.Clock()
delta_time=1
def getevent():
    global mouse_scroll,mouse_pos,mouse_rel,mouse_down,click,ctimer,keys,run
    mouse_scroll=0
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if event.type==pygame.MOUSEWHEEL:
            mouse_scroll=event.y
    mouse_down=pygame.mouse.get_pressed()
    mouse_pos=pygame.mouse.get_pos()
    mouse_rel=pygame.mouse.get_rel()
    mouse_pos=[mouse_pos[i]/size_offset[i] for i in range(2)]
    mouse_rel=[mouse_rel[i]/size_offset[i] for i in range(2)]
    ctimer=[(ctimer[i]+1)*mouse_down[i] for i in range(3)]
    click=[ctimer[i]==1 for i in range(3)]
    FPS=clock.get_fps()
    return f"""
try:
    global mouse_scroll,mouse_pos,mouse_rel,mouse_down,click,ctimer,keys,run
except:
    pass 
mouse_pos={mouse_pos}
mouse_down={mouse_down}
mouse_rel={mouse_rel}
mouse_scroll={mouse_scroll}
FPS={int(FPS)}
click={click}
ctimer={ctimer}
keys=pygame.key.get_pressed()
run={run}
try:
    delta_time=100/FPS
except:
    delta_time=1
    """
    return {
        MouseDownKey:mouse_down,
        MousePosKey:mouse_pos,
        MouseRelKey:mouse_rel,
        MouseScrollKey:mouse_scroll,
        ClickKey:click,
        CtimerKey:ctimer,
        ScriptRunKey:run,
        PressedKeyKey:keys,
        FPSKey:FPS,
    }
def center(sprite,screen,x,y):
    screen.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))
croll=lambda x:-int(log(random(),x))
def endframe():
    screen.blit(pygame.transform.scale(win,screen.get_size()),(0,0))
    pygame.display.update()
    clock.tick()
fonts={}
texts={}
def render_text(text="TEXT NOT PROVIDED",
        size=20,
        color=(255,255,255),
        font="courier new",
        bold=False,
        italic=False):
    font_key=str(font)+str(int(bold))+str(int(italic))+str(size)
    text_key=font_key+str(text)+str(color)
    if not font_key in fonts:
        fonts[font_key]=pygame.font.SysFont(str(font),int(size),bold,italic)
    if not text_key in texts:
        texts[text_key]=fonts[font_key].render(str(text),1,color)
    return texts[text_key]
def romanify(number):
    output=""
    if number>=100:         number-=100;output+="C"
    elif number>=90:        number-=90; output+="XC"
    if number>=50:          number-=50; output+="L"
    elif number>=40:        number-=40; output+="XL"
    for i in range(3):
        if number>=10:      number-=10; output+="X"
    if number>=9:           number-=9;  output+="IX"
    if number>=5:           number-=5;  output+="V"
    elif number>=4:         number-=4;  output+="IV"
    for i in range(3):
        if number>=1:       number-=1;  output+="I"
    return output
def log_display(x,base=2):
    if x>0.5:   return -1-log(1-x,base)
    else:       return 1+log(x,base)