from math import *
from random import *
import pygame
pygame.init()
Ssheet=pygame.image.load("Assets\SpriteSheetxcf.xcf")
shopsprites=[
    [
        pygame.transform.scale(pygame.image.load("Assets\ShopSprites\Derek\Derek.jpg"),(600,600)),
        pygame.transform.scale(pygame.image.load("Assets\ShopSprites\Derek\Derek Static.jpg"),(600,600)),
        ]
    ]
for i in shopsprites[0]:
    i=pygame.transform.scale(i,(600,600))
Shop_lore=[
    [
        "As you turn your head, you hear the sound of what",
        "could only be described as something 'crispy'. ",
        "As soon as you turn, ready to defend yourself,",
        "you see a burnt skeleton, made out of pure gold.",
        "He looks at you, and asks: 'Would ya like a bit",
        "of what i have?', and a deck of cards materializes",
        "in front of him. ",
        ],
    [
        ""
        ],
    [
        ""
        ],
    
    ]
