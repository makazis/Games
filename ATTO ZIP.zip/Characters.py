from math import *
from random import *
from Equipment import *
import pygame
import json
import os
pygame.init()
CHARACTERS={}
for root, dirs, files in os.walk(r"Assets\\Data\\JSON\\Characters"):
    for file in files:
        if file.endswith('.json'):
            CHARACTERS.update(json.loads(open(os.path.join(root,file),"r").read())) 
MOVES={}
for root, dirs, files in os.walk(r"Assets\\Data\\JSON\\Moves"):
    for file in files:
        if file.endswith('.json'):
            MOVES.update(json.loads(open(os.path.join(root,file),"r").read())) 
fonts={}
texts={}
def produce(font,size,text,color):
    text=str(text)
    global fonts,texts
    font_key=font+str(size)+text+str(color)
    if not font+str(size) in fonts:
        fonts[font+str(size)]=pygame.font.SysFont(font,size)
    if not font_key in texts:
        texts[font_key]=fonts[font+str(size)].render(text,1,color)
    return texts[font_key]
def center(sprite,surface,x,y):
    try:
        surface.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))
    except Exception as e:
        print(e)
class Button:
    def __init__(self,Size,Text):
        self.size=Size
        self.text=Text
        self.size_factor=1
        self.sprite=pygame.Surface(self.size)
        pygame.draw.rect(self.sprite,(205,205,0),(0,0,self.size[0],self.size[1]),5,5)
        center(produce("courier new",round(self.size[0]/0.8/len(self.text)),self.text,(205,205,0)),self.sprite,self.size[0]/2,self.size[1]/2)
    def exist(self,x,y,surface,mouse_data=[]):
        center(pygame.transform.scale(self.sprite,(self.size[0]*self.size_factor,self.size[1]*self.size_factor)),surface,x,y)
        if self.size[0]/2+x>mouse_data[0]>x-self.size[0]/2 and self.size[1]/2+y>mouse_data[1]>y-self.size[1]/2: 
            self.size_factor=min(1.2,self.size_factor+0.01)
            if mouse_data[2]:
                return True
        else: self.size_factor=max(1,self.size_factor-0.01)
        return False
for i in CHARACTERS:
    CHARACTERS[i]["DISPLAYBUTTON"]=Button((500,80),i)
class Character:
    def __init__(self,tips):
        self.tips=tips
        self.first_name=self.tips
        self.equipped={
            "Head":Equipment("None"),
            "Body":Equipment("None"),
            "Leggings":Equipment("None"),
            "Boots":Equipment("None"),

            "Necklace":Equipment("None"),
            "Amulet":Equipment("None"),

            "P Weapon":Equipment("None"),
            "S Weapon":Equipment("None"),
            }
        if "Starting Equippment" in CHARACTERS[self.tips]:
            for i in CHARACTERS[self.tips]["Starting Equippment"]:
                self.equipped[i]=Equipment(CHARACTERS[self.tips]["Starting Equippment"][i])
        self.calculate_stats()
        self.max_hp=self.stats["Health"]*20
        self.deck=[]
        for i in CHARACTERS[self.tips]["Starting Deck"]:
            self.deck.append(Move(i))
        self.button=Button((200,40),self.first_name)
        #print(self.stats)
    def calculate_stats(self):
        self.equipped_list=[self.equipped[i].tips for i in self.equipped]
        self.stats=CHARACTERS[self.tips]["Base Stats"].copy()
        for i in Pmods:
            if not i in self.stats:
                self.stats[i]=1
        for i in range(len(set_bonuses)):
            complete_set=True
            for i1 in range(len(set_bonuses[i]["Pieces"])):
                if not set_bonuses[i]["Pieces"][i1] in self.equipped_list:
                    complete_set=False
            if complete_set:
                for i1 in set_bonuses[i]["Modifiers"]:
                    self.stats[i1]*=set_bonuses[i]["Modifiers"][i1]
        for i in self.equipped:
            for i1 in self.equipped[i].Modifiers:
                self.stats[i1]*=self.equipped[i].Modifiers[i1]
        for i in self.stats:
            self.stats[i]=round(self.stats[i],3)
    def deal_damage(self,target,ammount):
        target.hp=max(0,target.hp-calculate_damage(self,target,ammount))
class Move:
    def __init__(self,tips):
        self.tips=tips
        self.data=MOVES[self.tips].copy()
        self.mana_cost=self.data["Energy Cost"]
        self.effects=[i.copy() for i in self.data["Effects"].copy()]
        for i in self.effects:
            #print(i)
            if randint(1,3)==1:
                i["Ammount"]*=1+random()/5
            else:
                i["Ammount"]/=1+random()/5
            i["Ammount"]=int(i["Ammount"])
        self.sprite=pygame.Surface((140,180))
        self.color=(randint(5,125),randint(5,125),randint(5,125))
        pygame.draw.rect(self.sprite,self.color,(7,7,126,166),0,7)
        center(produce("courier new",20,self.tips,(255,255,255)),self.sprite,70,20)
        for i in range(len(self.effects)):
            text=self.effects[i]["Type"]+": "+str(self.effects[i]["Ammount"])
            center(produce("courier new",int(170/len(text)),text,(255,255,255)),self.sprite,70,40+i*20)
        #print(self.effects)
def calculate_damage(Attacker,Defender,Ammount,additional_modifier=1):
    return int(Attacker.stats["Offense"]/Defender.stats["Defense"]*Ammount*additional_modifier)
#alpha=Character("Tomulon")
#beta=Character("Tomulon")
for i in MOVES:
    counter=0
    MOVES[i]["Prime Sprite"]=pygame.Surface((140,180))
    pygame.draw.rect(MOVES[i]["Prime Sprite"],(55,55,55),(7,7,126,166),0,7)
    center(produce("courier new",20,i,(255,255,255)),MOVES[i]["Prime Sprite"],70,20)
    for i1 in range(len(MOVES[i]["Effects"])):
        text=MOVES[i]["Effects"][i1]["Type"]+": "+str(int(MOVES[i]["Effects"][i1]["Ammount"]))
        counter+=1
        center(produce("courier new",int(170/len(text)),text,(255,255,255)),MOVES[i]["Prime Sprite"],70,20+counter*20)