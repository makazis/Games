from math import *
from random import *
import json
import os
EQUIPMENT_CHART={}
set_bonuses=[]
for location in [
    r"Assets\\Data\\JSON\\Armor",
    r"Assets\\Data\\JSON\\Weapons",
]:
    for root, dirs, files in os.walk(location):
        for file in files:
            if file.endswith('.json'):
                EQUIPMENT_CHART.update(json.loads(open(os.path.join(root,file),"r").read())) 
for root, dirs, files in os.walk(r"Assets\\Data\\JSON\\Setbonus"):
    for file in files:
        if file.endswith('.json'):
            set_bonuses+=json.loads(open(os.path.join(root,file),"r").read())["Sets"] 
Pmods=[
    "Defense",
    "Health",
    "Offense",
    "Healing",
    "Blocking", #block increase
    "Speed",
    "Greed", #card draw
    ]
class Equipment:
    def __init__(self,tips):
        self.tips=tips
        self.Modifiers={}
        self.mutation_ammount=EQUIPMENT_CHART[self.tips]["mutation ammount"]
        self.display=[]
        for i in Pmods:
            if i in EQUIPMENT_CHART[self.tips]["Modifiers"]:
                self.Modifiers[i]=round(EQUIPMENT_CHART[self.tips]["Modifiers"][i]*(1+(random()-0.5)*2*self.mutation_ammount),3)
                if self.Modifiers[i]>1:
                    self.display.append(i+": +"+str(round(100*(self.Modifiers[i]-1),1))+"%")
                else:
                    self.display.append(i+": "+str(round(100*(self.Modifiers[i]-1),1))+"%")
            else: self.Modifiers[i]=1
        #print(self.display)
#equiped={
#    "Head":Equipment("Wooden Helmet"),
#    "Body":Equipment("None"),
#    "Leggings":Equipment("None"),
#    "Boots":Equipment("None"),
#    "Necklace":Equipment("None"),
#    }
