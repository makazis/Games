from math import *
from random import *
import pygame
from Characters import *
pygame.init()
win=pygame.display.set_mode((0,0))
Screen=pygame.Surface((1200,600))
mouse_pos_offset=(1200/win.get_width(),600/win.get_height())
run=True
clock=pygame.time.Clock()
ctimer=[0,0,0]
def uvent():
    global run,keys,mouse_down,mouse_pos,click,ctimer
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    keys=pygame.key.get_pressed()
    if keys[27]:
        run=False
    mouse_pos=pygame.mouse.get_pos()
    mouse_pos=[mouse_pos[i]*mouse_pos_offset[i] for i in range(2)]
    mouse_down=pygame.mouse.get_pressed()
    for i in range(3):
        if mouse_down[i]: ctimer[i]+=1
        else: ctimer[i]=0
    click=[i==1 for i in ctimer]
def menu_screen():
    phase="Main_0"
    Play_Button=Button((400,100),"PLAY")
    Options_Button=Button((400,100),"OPTIONS")
    Six_Save_file_buttons=[Button((100,300),str(i+1)) for i in range(7)] # but seven were anough
    New_Game_button=Button((100,50),"NEW GAME")
    Back_button=Button((100,50),"BACK")
    C_S_S=pygame.Surface((600,len(CHARACTERS)*100))
    C_S_S_c_y=0
    Add_Character_Button=Button((80,40),"ADD")
    Remove_Character_Button=Button((160,40),"REMOVE")
    Start_Game_Button=Button((130,40),"START")
    while run:
        uvent()
        button_data=[mouse_pos[0],mouse_pos[1],click[0]]
        Screen.fill((0,0,0))
        pygame.draw.rect(Screen,(205,205,0),(55,55,1090,490),2)
        if phase=="Main_0":
            if Play_Button.exist(600,225,Screen,button_data): phase="Main_1"
            if Options_Button.exist(600,375,Screen,button_data): phase="OPTIONS"
        elif phase=="OPTIONS":
            phase="Main_0"
        elif phase=="Main_1":
            center(produce("courier new",30,"Choose Your Save File",(205,205,0)),
                   Screen,600,150)
            for i in range(7):
                if Six_Save_file_buttons[i].exist(150+i*150,350,Screen,button_data): phase="Checking "+str(i+1)
        for i in range(7):
            if phase=="Checking "+str(i+1):
                save_path="Assets\\Data\\Saves\\Save1"
                if Back_button.exist(150,500,Screen,button_data): phase="Main_1"
                if New_Game_button.exist(1050,500,Screen,button_data): 
                    phase="Main_2"
                    save_slot=i
                    Teams=[
                            {
                            "Name":"Team 1",
                            "Members":[],
                            "Button":Button((200,50),"Team 1"),
                            "Open":False,
                            "ACbutton":Button((160,30),"Add Character"),
                        },
                        {
                            "Name":"Team 2",
                            "Members":[],
                            "Button":Button((200,50),"Team 2"),
                            "Open":False,
                            "ACbutton":Button((160,30),"Add Character"),
                        },
                        {
                            "Name":"Team 3",
                            "Members":[],
                            "Button":Button((200,50),"Team 3"),
                            "Open":False,
                            "ACbutton":Button((160,30),"Add Character"),
                        },
                        {
                            "Name":"Team 4",
                            "Members":[],
                            "Button":Button((200,50),"Team 4"),
                            "Open":False,
                            "ACbutton":Button((160,30),"Add Character"),
                        },
                        
                    ]
        if phase=="Main_2": ##MENU PHASE WHERE THE CHARACTERS ARE DISPLAYED IN THEIR TEAMS
            openings=0
            character_count=0
            for i in Teams:
                openings+=225
                hx=50
                if i["Button"].exist(50+openings,100,Screen,button_data): i["Open"]=not i["Open"]
                if i["Open"]:
                    for i1 in range(len(i["Members"])):
                        if i["Members"][i1].button.exist(50+openings,100+hx,Screen,button_data): phase="Checking A Character";selected_character=i["Members"][i1];sc=i["Members"][i1]
                        hx+=50
                        character_count+=1
                    if len(i["Members"])<8:
                        if i["ACbutton"].exist(50+openings,100+hx,Screen,button_data): phase="Adding A Character";selected_team=i
            if character_count: 
                if Start_Game_Button.exist(1040,470,Screen,button_data): break
        elif phase=="Adding A Character":
            C_S_S.fill((0,0,0))
            hx=-1
            obutton_data=[button_data[0]-300,button_data[1]-100,click[0]]
            for i in CHARACTERS:
                hx+=1
                if CHARACTERS[i]["DISPLAYBUTTON"].exist(300,hx*100+50,C_S_S,obutton_data): 
                    phase="Displaying A Character"
                    selected_character=i
                    sc=Character(i)
            Screen.blit(C_S_S.subsurface((0,0,600,min(len(CHARACTERS)*100,400))),(300,100))
        elif phase=="Displaying A Character":
            Screen.fill((0,0,0))
            center(produce("courier new",20,selected_character,(255,255,255)),Screen,600,15)
            center(produce("courier new",20,"HP: "+str(round(sc.max_hp)),(255,255,255)),Screen,300,30)
            counter=0
            for i in CHARACTERS[sc.tips]["Base Stats"]:
                if i!="Health":
                    counter+=1
                    if CHARACTERS[sc.tips]["Base Stats"][i]>1:
                        center(produce("courier new",20,i+": +"+str(abs(round(CHARACTERS[sc.tips]["Base Stats"][i]*100-100,1)))+"%",(255,255,255)),Screen,300,30+counter*20)
            
            counter=0
            for i in sc.equipped:
                if sc.equipped[i].tips!="None":
                    counter+=1
                    bsprite=produce("courier new",20,i+": "+sc.equipped[i].tips,(255,255,255))
                    center(bsprite,Screen,600,30+counter*20)
                    if 600+bsprite.get_width()/2>mouse_pos[0]>600-bsprite.get_width()/2 and 30+counter*20+10>mouse_pos[1]>30+counter*20-10:
                        counter2=0
                        for i1 in EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"]:
                            counter2+=1
                            if EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"][i1]<1:
                                center(produce("courier new",20,i1+": -"+str(abs(round(EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"][i1]*100-100,1)))+"%",(255,255,255)),Screen,600,590-counter2*20)
                            else:
                                center(produce("courier new",20,i1+": +"+str(abs(round(EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"][i1]*100-100,1)))+"%",(255,255,255)),Screen,600,590-counter2*20)
            center(produce("courier new",20,"Starting Deck",(255,255,255)),Screen,900,30)
            counter=0
            for i in sc.deck:
                counter+=1
                bsprite=produce("courier new",20,i.tips,(255,255,255))
                center(bsprite,Screen,900,30+counter*20)
                if 900+bsprite.get_width()/2>mouse_pos[0]>900-bsprite.get_width()/2 and 30+counter*20+10>mouse_pos[1]>30+counter*20-10:
                    center(MOVES[i.tips]["Prime Sprite"],Screen,900,450)
            if Add_Character_Button.exist(1120,550,Screen,button_data): phase="Main_2";selected_team["Members"].append(sc)
            elif Back_button.exist(80,550,Screen,button_data): phase="Adding A Character"
        elif phase=="Checking A Character":
            Screen.fill((0,0,0))
            center(produce("courier new",20,sc.tips,(255,255,255)),Screen,600,15)
            center(produce("courier new",20,"HP: "+str(round(sc.max_hp)),(255,255,255)),Screen,300,30)
            counter=0
            for i in CHARACTERS[sc.tips]["Base Stats"]:
                if i!="Health":
                    counter+=1
                    if CHARACTERS[sc.tips]["Base Stats"][i]>1:
                        center(produce("courier new",20,i+": +"+str(abs(round(CHARACTERS[sc.tips]["Base Stats"][i]*100-100,1)))+"%",(255,255,255)),Screen,300,30+counter*20)
            
            counter=0
            for i in sc.equipped:
                if sc.equipped[i].tips!="None":
                    counter+=1
                    bsprite=produce("courier new",20,i+": "+sc.equipped[i].tips,(255,255,255))
                    center(bsprite,Screen,600,30+counter*20)
                    if 600+bsprite.get_width()/2>mouse_pos[0]>600-bsprite.get_width()/2 and 30+counter*20+10>mouse_pos[1]>30+counter*20-10:
                        counter2=0
                        for i1 in EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"]:
                            counter2+=1
                            if EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"][i1]<1:
                                center(produce("courier new",20,i1+": -"+str(abs(round(EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"][i1]*100-100,1)))+"%",(255,255,255)),Screen,600,590-counter2*20)
                            else:
                                center(produce("courier new",20,i1+": +"+str(abs(round(EQUIPMENT_CHART[sc.equipped[i].tips]["Modifiers"][i1]*100-100,1)))+"%",(255,255,255)),Screen,600,590-counter2*20)
            center(produce("courier new",20,"Starting Deck",(255,255,255)),Screen,900,30)
            counter=0
            for i in sc.deck:
                counter+=1
                bsprite=produce("courier new",20,i.tips,(255,255,255))
                center(bsprite,Screen,900,30+counter*20)
                if 900+bsprite.get_width()/2>mouse_pos[0]>900-bsprite.get_width()/2 and 30+counter*20+10>mouse_pos[1]>30+counter*20-10:
                    center(MOVES[i.tips]["Prime Sprite"],Screen,900,450)
            if Remove_Character_Button.exist(1120,550,Screen,button_data): phase="Main_2";selected_team["Members"].remove(sc)
            elif Back_button.exist(80,550,Screen,button_data): phase="Main_2"
        clock.tick(100)
        win.blit(pygame.transform.scale(Screen,win.get_size()),(0,0))
        pygame.display.update()
    print("MAY THE GAMES BEGIN")
    MAP()
def MAP():
    while run:
        uvent()
        button_data=[mouse_pos[0],mouse_pos[1],click[0]]
        Screen.fill((0,0,0))
menu_screen()
pygame.quit()
