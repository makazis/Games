from random import *
from math import *
import os
import json
import pygame
import pygame.gfxdraw
pygame.init()
difficulty_adjustment=3 #2 is easy, 3 is normal, 5 is harder
win=pygame.Surface((1800,900))
#win.set_alpha(155)
g=pygame.display.set_mode((1800,900))
upgrade_overlay=pygame.Surface((1800,900))
upgrade_overlay.set_colorkey((0,0,0))
run=True
clock=pygame.time.Clock()
drag=0.01
fonts={}
texts={}
def produce(text="",size=20,color=(255,255,255),font="comicsansms"):
    font_key=font+str(size)
    text_key=font+str(size)+str(color)+str(text)
    if not font_key in fonts:
        fonts[font_key]=pygame.font.SysFont(font,size)
    if not text_key in texts:
        texts[text_key]=fonts[font_key].render(text,1,color)
    return texts[text_key]
def center(sprite,surface,pos):
    surface.blit(sprite,(pos[0]-sprite.get_width()/2,pos[1]-sprite.get_height()/2))
with open("JSON\\Bullets.json","r") as file:
    bullet_data=json.loads(file.read())
bullet_sprite_data={
    B:pygame.Surface((30,30))for B in bullet_data
}
background_color=(0,0,0)
#background_color=(100,100,100)
hurtscreen=pygame.Surface((1800,900))
hurtscreen.fill((255,0,0))
for B in bullet_sprite_data:
    
    if type(bullet_data[B]["sprite"])==str:
        bullet_sprite_data[B]=pygame.transform.scale(pygame.image.load(f"Sprites\\Bullets\\{bullet_data[B]['sprite']}"),(30,30))
    else:
        for i1 in bullet_data[B]["sprite"]:
            if i1["type"]=="Sphere":
                pygame.gfxdraw.filled_circle(bullet_sprite_data[B],15,15,i1["size"]-1,i1["color"])
    bullet_sprite_data[B].set_colorkey(bullet_sprite_data[B].get_at((0,0)))
enemy_data={}
for root,dirs,files in os.walk(r"JSON\\Enemies\\"):
    for file in files:
        if file.endswith(".json"):
            #print(root,file)
            with open(root+"\\"+file,"r") as F:
                enemy_data[file[:-5]]=json.loads(F.read())
enemy_sprite_data={
    B:pygame.Surface((100,100))for B in enemy_data
}
for B in enemy_sprite_data:
    if type(enemy_data[B]["sprite"])==str:
        enemy_sprite_data[B]=pygame.image.load(f"Sprites\\Enemies\\{enemy_data[B]['sprite']}")
        if "sprite offset x" in enemy_data[B]:
            T_sprite=enemy_sprite_data[B].copy()
            enemy_sprite_data[B].fill((0,0,0))
            enemy_sprite_data[B].blit(T_sprite,(enemy_data[B]["sprite offset x"],0))
        if "sprite resize" in enemy_data[B]:
            enemy_sprite_data[B]=pygame.transform.scale(enemy_sprite_data[B],(enemy_sprite_data[B].get_width()*enemy_data[B]["sprite resize"],enemy_sprite_data[B].get_height()*enemy_data[B]["sprite resize"]))
    else:
        for i1 in enemy_data[B]["sprite"]:
            if i1["type"]=="Sphere":
                pygame.gfxdraw.filled_circle(enemy_sprite_data[B],50,50,i1["size"],i1["color"])
    enemy_sprite_data[B].set_colorkey(enemy_sprite_data[B].get_at((0,0)))
prime_bonus={
            "Bullet Speed":1,
            "Damage":1,
            "Extra Dash":1,
            "Speed":1,
            "Pierce":0,
            "Shootspeed":1,
            "Body Damage":1,
        }
class Player:
    def __init__(self):
        self.x=900
        self.y=450
        self.angle=0
        self.xspeed=0
        self.yspeed=0
        self.vectors=[]
        self.size=15
        self.bonus=prime_bonus.copy()
        self.abilities=[]
        self.ability_data={}
        self.reload_timer=0
        self.max_reload=40
        self.dash_timer=0
        self.max_dash_timer=500
        self.max_hp=100
        self.hp=self.max_hp
        self.invincibility_frame=0
        self.max_invincibility_frame=20
        self.subclass_alpha=""
    def move(self):
        
        for vector in self.vectors:
            self.xspeed+=vector[0]
            self.yspeed+=vector[1]
        self.vectors=[]
        self.xspeed*=1-drag
        self.yspeed*=1-drag
        self.x+=self.xspeed
        self.y+=self.yspeed
        self.speed_squared=self.xspeed**2+self.yspeed**2
        if self.speed_squared>77:
            for enemy in enemies:
                if enemy.last_hit>50:
                    if (self.size+enemy.hitbox_size)**2>(self.x-enemy.x)**2+(self.y-enemy.y)**2:
                        enemy.last_hit=0
                        damage_dealt=self.bonus["Body Damage"]*int((self.speed_squared-77)**(1/2))*self.bonus["Damage"]
                        enemy.hp-=damage_dealt
                        if self.subclass_alpha=="Leech":
                            self.hp=min(self.max_hp,self.hp+int(damage_dealt*self.ability_data["Leech"]["Heal"]/10))
                        particles.append(Particle((self.x,self.y),0,{"delta":self.angle}))
        if abs(self.x-900)>900:
            self.vectors.append([-(self.x-900)/10000,0])
        if abs(self.y-450)>450:
            self.vectors.append([0,-(self.y-450)/5000])
        self.invincibility_frame-=int(self.invincibility_frame>0)
    
    def draw(self):
        if self.speed_squared>77:
            extra_distance=sqrt(self.speed_squared)
            pygame.draw.polygon(win,(255,255,255),[[cos(self.angle+tau/2.5*polygon_point)*(self.size+extra_distance)+self.x,sin(self.angle+tau/2.5*polygon_point)*(self.size+extra_distance)+self.y] for polygon_point in range(5)],1)
        if self.subclass_alpha=="Leech":
            pygame.draw.polygon(win,(255,155,255),[[cos(self.angle+tau/2.5*polygon_point)*self.size+self.x,sin(self.angle+tau/2.5*polygon_point)*self.size+self.y] for polygon_point in range(5)])
        if self.subclass_alpha=="Rogue":
            pygame.draw.polygon(win,(255,255,155),[[cos(self.angle+tau/2.5*polygon_point)*self.size+self.x,sin(self.angle+tau/2.5*polygon_point)*self.size+self.y] for polygon_point in range(5)])
        
        pygame.draw.polygon(win,(255,255,255),[[cos(self.angle+tau/2.5*polygon_point)*self.size+self.x,sin(self.angle+tau/2.5*polygon_point)*self.size+self.y] for polygon_point in range(5)],1)
class Bullet:
    def __init__(self, tips, owner):
        self.friendly=(owner==p)
        try:
            self.friendly=owner.friendly
        except: pass
        self.x=owner.x
        self.owner=owner
        self.y=owner.y
        self.tips=tips
        self.speed=bullet_data[self.tips]["speed"]*(self.owner.bonus["Bullet Speed"])
        self.pierce=bullet_data[self.tips]["pierce"]+self.owner.bonus["Pierce"]
        self.angle=self.owner.angle
        self.sprite=bullet_sprite_data[self.tips]
        self.xspeed=cos(owner.angle)*self.speed
        self.yspeed=sin(owner.angle)*self.speed
        self.vectors=[]
        self.pierced_enemies=[]
        self.hitbox_size=bullet_data[self.tips]["hitbox size"]
        self.damage=bullet_data[self.tips]["damage"]*(self.owner.bonus["Damage"])
        self.special_behaviour=bullet_data[self.tips]["special behaviour"]
    def move(self):
        for vector in self.vectors:
            self.xspeed+=vector[0]
            self.yspeed+=vector[1]
        self.vectors=[]
        self.x+=self.xspeed
        self.y+=self.yspeed
        
        self.x=min(3600,max(-1800,self.x))
        self.y=min(1800,max(-900,self.y))
        if self.friendly:
            for i in enemies:
                if not i in self.pierced_enemies:
                    distance_to_enemy=sqrt((self.y-i.y)**2+(self.x-i.x)**2)
                    if distance_to_enemy<self.hitbox_size+i.hitbox_size:
                        self.pierce-=1
                        self.pierced_enemies.append(i)
                        i.hp-=self.damage
                        if self.tips=="Standart":
                            particles.append(Particle((self.x,self.y),0,{"delta":self.angle}))
                        elif self.tips=="Lightning":
                            particles.append(Particle((self.x,self.y),1,{"delta":self.angle,"count":randint(3,10),"color":(155,255,155)}))
                    if self.tips=="Lightning":
                        if distance_to_enemy<100:
                            particles.append(Particle((self.x,self.y),1,{"delta":self.atan2(self.y-i.y,self.x-i.x),"count":1,"color":(155,255,155),"power":13}))
        else:
            distance_to_enemy=sqrt((self.y-p.y)**2+(self.x-p.x)**2)
            if distance_to_enemy<self.hitbox_size+p.size:
                if p.invincibility_frame==0:
                    self.pierce-=1
                    self.pierced_enemies.append(p)
                    p.hp-=self.damage
                    if self.tips=="Standart":
                        particles.append(Particle((self.x,self.y),0,{"delta":self.angle}))
                    elif self.tips=="Lightning":
                        particles.append(Particle((self.x,self.y),1,{"delta":self.angle,"count":1,"color":(155,255,155)}))
                    p.invincibility_frame=p.max_invincibility_frame
                if self.tips=="Lightning":
                    p.vectors.append([-cos(self.angle)*6,-sin(self.angle)*6])
            if self.tips=="Lightning":
                if distance_to_enemy<100:
                    attack_angle=-atan2(self.y-p.y,self.x-p.x)
                    particles.append(Particle((self.x,self.y),1,{"delta":attack_angle,"count":1,"color":(155,255,155),"power":13,"decay":1}))
                    p.vectors.append([cos(-attack_angle)/4,sin(-attack_angle)/4])
        if self.tips=="Lightning":
            for i in bullets:
                if i.tips!="Lightning":
                    distance_to_enemy=sqrt((self.y-i.y)**2+(self.x-i.x)**2)
                    if distance_to_enemy<100:
                        attack_angle=-atan2(self.y-i.y,self.x-i.x)
                        #particles.append(Particle((self.x,self.y),1,{"delta":attack_angle,"count":1,"color":(155,255,155),"power":13,"decay":1}))
                        i.vectors.append([cos(-attack_angle)/2,sin(-attack_angle)/2])
        if self.x in [3600,-1800] or self.y in [1800,-900]:
            self.despawn()
        if self.pierce<=-1:
            self.despawn()
    def draw(self):
        
        center(pygame.transform.rotate(self.sprite,180-self.angle/pi*180),win,(self.x,self.y))
        if self.tips=="Lightning" and random()<0.1:
            particles.append(Particle((self.x,self.y),1,{"delta":-self.angle,"count":1,"color":(155,255,155)}))
    def despawn(self):
        if self in bullets:
            bullets.remove(self)
        del self


class Enemy:
    def __init__(self, tips, additional_data={}):
        self.x=random()*1800
        self.y=-100
        self.xspeed=0
        self.yspeed=0
        self.angle=0
        self.vectors=[]
        self.bonus=prime_bonus.copy()
        self.tips=tips
        self.data=enemy_data[self.tips]
        self.AI=self.data["AI"]
        self.AI_keys=[i["type"] for i in self.AI]
        if "bonus" in self.data:
            for i in self.data["bonus"]:
                self.bonus[i]=self.data["bonus"][i]
        for i in self.AI:
            if i["type"]=="Follows Player":
                if "Angle Offset" in i["Attributes"]:
                    self.angular_offset=i["Attributes"]["Angle Offset"]*(random()-0.5)*2
                else:
                    self.angular_offset=0
                if "Speed" in i["Attributes"]: self.follow_player_speed=i["Attributes"]["Speed"]
                else: self.follow_player_speed=10
                if "Distance" in i["Attributes"]:
                    self.follow_distance=i["Attributes"]["Distance"]
                else: self.follow_distance=0
                self.follow_player_speed=self.follow_player_speed**(0.95+random()/10)
            if i["type"]=="Damages on contact":
                if "Damage" in i["Attributes"]:
                    self.on_contact_damage=i["Attributes"]["Damage"]
                else:
                    self.on_contact_damage=5
            if i["type"]=="Shoots at Player":
                if "Reload Time" in i["Attributes"]:
                    self.reload_max_timer=i["Attributes"]["Reload Time"]
                else:
                    self.reload_max_timer=100
                self.reload_timer=randint(0,self.reload_max_timer)
                if "Bullet Type" in i["Attributes"]:
                    self.bullet_type=i["Attributes"]["Bullet Type"]
                else:
                    self.bullet_type="Standart"
                if "Accuracy" in i["Attributes"]:
                    self.shot_offset=1-i["Attributes"]["Accuracy"]
                else: self.shot_offset=0
                if "Bullet Count" in i["Attributes"]:
                    self.bullet_count=i["Attributes"]["Bullet Count"]
                else:
                    self.bullet_count=1
            if i["type"]=="Spawns On Death":
                self.spawns_on_death=i["Attributes"]["Entity Spawned"]
                if "Count" in i["Attributes"]:
                    self.spawn_on_death_entity_count=i["Attributes"]["Count"]
                else: self.spawn_on_death_entity_count=1
            if i["type"]=="Moves Player":
                if "Max Distance" in i["Attributes"]:
                    self.maximum_move_player_distance=i["Attributes"]["Max Distance"]
                else:
                    self.maximum_move_player_distance=10000
                if "Strength" in i["Attributes"]:
                    self.move_player_strength=i["Attributes"]["Strength"]
                else:
                    self.move_player_strength=1
        self.sprite=enemy_sprite_data[self.tips]
        self.hitbox_size=self.data["hitbox size"]
        self.hp=self.data["max_hp"]
        self.last_hit=0
    def move(self):
        for vector in self.vectors:
            self.xspeed+=vector[0]
            self.yspeed+=vector[1]
        self.vectors=[]
        self.xspeed*=1-drag
        self.yspeed*=1-drag
        
        self.x+=self.xspeed
        self.y+=self.yspeed
        if abs(self.x-900)>900:
            self.vectors.append([-(self.x-900)/10000,0])
        if abs(self.y-450)>450:
            self.vectors.append([0,-(self.y-450)/5000])
        if self.hp<=0:
            self.despawn()
        self.last_hit+=1
    def draw(self):
        center(pygame.transform.rotate(self.sprite,180-self.angle/pi*180),win,(self.x,self.y))
    def think(self):
        
        for AI_POINT in self.AI:
            if AI_POINT["type"]=="Follows Player":
                self.distance_to_player=sqrt((self.x-p.x)**2+(self.y-p.y)**2)
                self.angle=pi+atan2(self.y-p.y,self.x-p.x)+self.angular_offset
                if self.follow_distance-self.distance_to_player>0:
                    self.vectors.append([-cos(self.angle)/100*self.follow_player_speed,-sin(self.angle)/100*self.follow_player_speed])
                else:
                    self.vectors.append([cos(self.angle)/100*self.follow_player_speed,sin(self.angle)/100*self.follow_player_speed])
            if p.invincibility_frame==0:
                if AI_POINT["type"]=="Damages on contact":
                    self.distance_to_player=sqrt((self.x-p.x)**2+(self.y-p.y)**2)
                    if self.distance_to_player<self.hitbox_size+p.size:
                        p.invincibility_frame=p.max_invincibility_frame
                        p.hp-=self.on_contact_damage
            if AI_POINT["type"]=="Shoots at Player":
                self.angle=pi+atan2(self.y-p.y,self.x-p.x)
                self.reload_timer-=1
                if self.reload_timer==0:
                    self.true_angle=self.angle
                    for i in range(self.bullet_count):
                        self.angle=pi+atan2(self.y-p.y,self.x-p.x)+self.shot_offset*(random()-0.5)*2
                        self.reload_timer=self.reload_max_timer
                        bullets.append(Bullet(self.bullet_type,self))
                    self.angle=self.true_angle
    def despawn(self):
        if "Spawns On Death" in self.AI_keys:
            for i in range(self.spawn_on_death_entity_count):
                enemies.append(Enemy(self.spawns_on_death))
                enemies[-1].x=self.x+randint(-i,i)
                enemies[-1].y=self.y+randint(-i,i)
        if self in enemies:
            enemies.remove(self)
        del self


class Particle:
    def __init__(self,pos,tips,data={}):
        self.pos=pos
        self.tips=tips
        self.frame=0
        if self.tips==0: #WHITE Explosion
            if "delta" in data:
                self.delta=data["delta"]
            else:
                self.delta=random()*tau
            self.parts=[[self.delta+(random()-0.5)*2,0,5,(-0.2-random())/5] for i in range(randint(3,randint(6,12)))]
        elif self.tips==1: #Lightning
            if "delta" in data:
                self.delta=data["delta"]
            else:
                self.delta=random()*tau
            if "power" in data:
                self.power=data["power"]
            else:
                self.power=10
            if "count" in data:
                self.count=data["count"]
            else:
                self.count=1
            if "color" in data:
                self.color=data["color"]
            else:
                self.color=(255,255,255)
            if "decay" in data:
                self.decay=data["decay"]
            else:
                self.decay=0.33
            self.parts=[[self.delta+(random()-0.5)*2,[(self.pos[0],self.pos[1]) for i in range(self.power)]] for i in range(self.count)]
    def animate(self):
        self.frame+=1
        if self.tips==0:
            for i in self.parts:
                i[2]+=i[3]
                i[1]+=i[2]
                if i[2]<0:
                    self.parts.remove(i)
                    break
                else:
                    center_x=cos(i[0])*3*i[1]+self.pos[0]
                    center_y=sin(i[0])*3*i[1]+self.pos[1]
                    cq=255-i[2]/5*255
                    pygame.draw.polygon(win,(cq,cq,cq),[(center_x+cos(tau/3*i1+i[1]/10)*(i[2]),center_y+sin(tau/3*i1+i[1]/10)*(i[2])) for i1 in range(3)])
            if len(self.parts)==0: 
                self.despawn()
        if self.tips==1:
            for i in self.parts:
                if random()<self.decay:
                    added_spark_angle=self.delta+(random()-0.5)*2*1.5
                    i[1].append([i[1][-1][0]+cos(added_spark_angle)*len(i[1]),i[1][-1][1]+sin(added_spark_angle)*len(i[1])])
                    i[1].pop(0)
                    i[1].pop(0)
                    if len(i[1])==0:
                        self.parts.remove(i)
                        break
                for i1 in enumerate(i[1]):
                    if i1[0]>0:
                        pygame.draw.line(win,self.color,i1[1],i[1][i1[0]-1])
                #if i[2]<0:
                #    
                #else:
                #    center_x=cos(i[0])*3*i[1]+self.pos[0]
                #    center_y=sin(i[0])*3*i[1]+self.pos[1]
                #    cq=255-i[2]/5*255
                #    pygame.draw.polygon(win,(cq,cq,cq),[(center_x+cos(tau/3*i1+i[1]/10)*(i[2]),center_y+sin(tau/3*i1+i[1]/10)*(i[2])) for i1 in range(3)])
            if len(self.parts)==0: 
                self.despawn()
        
    def despawn(self):
        if self in particles:
            particles.remove(self)
        del self
p=Player()
particles=[]
bullets=[]
enemies=[]

ctimer=[0,0,0]
click=[False,False,False]
keylistener=[
    pygame.K_s
]
kdf=[0 for i in keylistener]
kbool=[False for i in kdf]
required_difficulty_level=1.1
mouse_pos=[0,0]
mouse_down=[False,False,False]
levelup_overlay=False
stage=0
while run and p.hp>0:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
   
    mouse_pos=pygame.mouse.get_pos()
    mouse_down=pygame.mouse.get_pressed()
    keys=pygame.key.get_pressed()
    ctimer=[(ctimer[i]+1)*mouse_down[i] for i in range(3)]
    click=[ctimer[i]==1 for i in range(3)]
    win.fill(background_color)
    difficulty_level=sum([enemy_data[enemy.tips]["difficulty level"] for enemy in enemies])
    if difficulty_level==0: #Level up!
        stage+=1
        pygame.display.set_caption(f"Current Level: {stage}")
        required_difficulty_level=ceil(required_difficulty_level**(1+difficulty_adjustment/required_difficulty_level))
        c=required_difficulty_level
        while c>0:
            for i in enemy_data:
                if enemy_data[i]["difficulty level"]<=c and random()>0.9:
                    enemies.append(Enemy(i))
                    c-=enemy_data[i]["difficulty level"]
                    break
        bullets=[]
        p.hp=min(p.max_hp,p.hp+p.max_hp/2.5)
        levelup_overlay=True
        upgrades_available=[
            "Dash+",
            "Speed+",
            "Damage+",
            "Size-",
            "Pierce+",
            "Shotspeed+",
            "Body Damage+",
            "Bullet Speed+"
        ]
        if not "South Pole" in p.abilities:
            upgrades_available.append("South Pole Unlock")
        if p.bonus["Body Damage"]>2.2 and p.subclass_alpha=="": #Subclass Choice
            upgrades_available.append("Leech Unlock") #Gain life from damaging enemies with dashing
            upgrades_available.append("Rogue Unlock") #Reduce cooldown of dashing, and have a chance to not take damage while you dash
            upgrades_available.append("Boost Unlock") #Temporary boost of speed instead of one continuous dash
        if p.subclass_alpha=="Leech":
            upgrades_available.append("Leech+")
        if p.subclass_alpha=="Rogue":
            upgrades_available.append("Rogue+")
        
        upgrades_given=[]
        for i in range(3):
            c=choice(upgrades_available)
            upgrades_given.append(c)
            upgrades_available.remove(c)
    if levelup_overlay:
        for i in range(3):
            pressed=False
            pygame.draw.rect(win,(0,0,0),(30+i*600,480,550,400))
            if 580+i*600>mouse_pos[0]>30+i*600 and 880>mouse_pos[1]>480:
                pygame.draw.rect(win,(255,255,0),(30+i*600,480,550,400),10,10)
                if click[0]:
                    pressed=True
            else:
                pygame.draw.rect(win,(255,255,255),(30+i*600,480,550,400),10,10)
            if upgrades_given[i]=="Dash+":
                center(produce("Dash is increased by 20%"),win,(330+i*600,500))
                center(produce("Press right click to dash"),win,(330+i*600,525))
                center(produce("Current dash bonus: "+str(round(p.bonus["Extra Dash"]*100-100))+"%"),win,(330+i*600,550))
                if pressed:
                    over=True
                    p.bonus["Extra Dash"]*=1.2
            if upgrades_given[i]=="Speed+":
                center(produce("Speed is increased by 14%"),win,(330+i*600,500))
                center(produce("Current speed bonus: "+str(round(p.bonus["Speed"]*100-100))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.bonus["Speed"]*=1.14
            if upgrades_given[i]=="Bullet Speed+":
                center(produce("Bullet speed is increased by 30%"),win,(330+i*600,500))
                center(produce("Current bullet speed bonus: "+str(round(p.bonus["Bullet Speed"]*100-100))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.bonus["Bullet Speed"]*=1.3
            if upgrades_given[i]=="Size-":
                center(produce("Your radius is decreased by"),win,(330+i*600,500))
                center(produce("A PIXEL!!!!"),win,(330+i*600,525))
                center(produce("Current radius: "+str(round(p.size))+" pixels"),win,(330+i*600,550))
                if pressed:
                    over=True
                    p.size-=1
            if upgrades_given[i]=="Damage+":
                center(produce("Damage is increased by 10%"),win,(330+i*600,500))
                center(produce("Current bonus: "+str(round(p.bonus["Damage"]*100-100))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.bonus["Damage"]*=1.1
            if upgrades_given[i]=="Pierce+":
                center(produce("Your Bullets Pierce an additional Enemy"),win,(330+i*600,500))
                center(produce("Current bonus: "+str(round(p.bonus["Pierce"]))),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.bonus["Pierce"]+=1
            if upgrades_given[i]=="Shotspeed+":
                center(produce("You shoot 10% faster"),win,(330+i*600,500))
                center(produce("Current bonus: "+str(round(p.bonus["Shootspeed"]*100-100))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.bonus["Shootspeed"]*=1.1
            if upgrades_given[i]=="Body Damage+":
                center(produce("You deal 30% more ramming damage"),win,(330+i*600,500))
                center(produce("Current bonus: "+str(round(p.bonus["Body Damage"]*100-100))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.bonus["Body Damage"]*=1.3
            if upgrades_given[i]=="South Pole Unlock":
                center(produce("Unlock the South Pole ability"),win,(330+i*600,500))
                center(produce("Press S to activate"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.abilities.append("South Pole")
                    p.ability_data["South Pole"]={
                        "Max Reload Time":400,
                        "Current Reload Time":0,
                        "Usetimer":0,
                        "Strength":1
                    }
                    
            if upgrades_given[i]=="Leech Unlock":
                center(produce("Unlock the Leech subclass"),win,(330+i*600,500))
                center(produce("Ramming enemies now heals you"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.abilities.append("Leech")
                    p.ability_data["Leech"]={
                        "Heal":1
                    }
                    p.subclass_alpha="Leech"
            if upgrades_given[i]=="Rogue Unlock":
                center(produce("Unlock the Rogue subclass"),win,(330+i*600,500))
                center(produce("Damaging enemies reduces the cooldown of your dash"),win,(315+i*600,525))
                if pressed:
                    over=True
                    p.abilities.append("Rogue")
                    p.ability_data["Rogue"]={
                        "Dash reduction per damage":1,
                        "Dash Reload Reduction":1.5
                    }
                    p.subclass_alpha="Rogue"
            if upgrades_given[i]=="Boost Unlock":
                center(produce("Unlock the Hell Rider subclass"),win,(330+i*600,500))
                center(produce("Instead of dashing, mount a hound of hell"),win,(330+i*600,525))
                center(produce("It ain't finished, so it sucks"),win,(330+i*600,550))
                
                if pressed:
                    over=True
                    p.abilities.append("Rider")
                    p.ability_data["Rider"]={
                        "Dash regeneration":1,
                        "Dash maximum":100
                    }
                    p.subclass_alpha="HellRider"
            if upgrades_given[i]=="Leech+":
                center(produce("You gain 20% more healing from your Leech ability"),win,(330+i*600,500))
                center(produce("Current bonus: "+str(round(p.ability_data["Leech"]["Heal"]*100-100))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.ability_data["Leech"]["Heal"]*=1.2
            if upgrades_given[i]=="Rogue+":
                center(produce("Your dash reload is reduced further"),win,(330+i*600,500))
                center(produce("Current bonus: "+str(round(100/p.ability_data["Rogue"]["Dash Reload Reduction"],2))+"%"),win,(330+i*600,525))
                if pressed:
                    over=True
                    p.ability_data["Rogue"]["Dash Reload Reduction"]*=1.2
            if pressed:
                levelup_overlay=False
    for i in enumerate(keylistener):
        if keys[i[1]]:
            kdf[i[0]]+=1
        else: kdf[i[0]]=0
        kbool[i[0]]=kdf[i[0]]==1
    rel_angle=pi+atan2(p.y-mouse_pos[1],p.x-mouse_pos[0])
    p.angle=rel_angle
    if mouse_down[0]:#Move function
        p.vectors.append([cos(p.angle)/10*p.bonus["Speed"],sin(p.angle)/10*p.bonus["Speed"]])
    if p.reload_timer<=0:
        if keys[pygame.K_SPACE]: #Shoot function
            bullets.append(Bullet("Standart",p))
            p.reload_timer=p.max_reload/p.bonus["Shootspeed"]
    else: p.reload_timer-=1
    if p.dash_timer>=0: 
        p.dash_timer-=1
        pygame.draw.line(win,(255,255,255),(0,p.dash_timer/p.max_dash_timer*100),(10,p.dash_timer/p.max_dash_timer*100))
    elif mouse_down[2]:
        p.vectors.append([cos(p.angle)*10*(p.bonus["Extra Dash"]),sin(p.angle)*10*(p.bonus["Extra Dash"])])
        p.dash_timer=p.max_dash_timer
        if p.subclass_alpha=="Rogue":
            p.dash_timer/=p.ability_data["Rogue"]["Dash Reload Reduction"]
    if "South Pole" in p.abilities:
        p.ability_data["South Pole"]["Current Reload Time"]-=p.ability_data["South Pole"]["Current Reload Time"]!=0
        pygame.draw.line(win,(255,255,0),(0,p.ability_data["South Pole"]["Current Reload Time"]/p.ability_data["South Pole"]["Max Reload Time"]*100),(10,p.ability_data["South Pole"]["Current Reload Time"]/p.ability_data["South Pole"]["Max Reload Time"]*100))
        if kbool[0]:
            if p.ability_data["South Pole"]["Current Reload Time"]<=0:
                p.ability_data["South Pole"]["Current Reload Time"]=p.ability_data["South Pole"]["Max Reload Time"]
                p.ability_data["South Pole"]["Usetimer"]=20
        
        if p.ability_data["South Pole"]["Usetimer"]>0:
            pygame.draw.circle(win,(55,55,0),(p.x,p.y),100-p.ability_data["South Pole"]["Usetimer"]*5,5)
            for i in enemies:
                distance=sqrt((i.x-p.x)**2+(i.y-p.y)**2)
                if distance<100-5*p.ability_data["South Pole"]["Usetimer"]:
                    i.vectors.append([-(p.x-i.x)/distance*p.ability_data["South Pole"]["Strength"],-(p.y-i.y)/distance*p.ability_data["South Pole"]["Strength"]])
                    #i.hp-=p.ability_data["South Pole"]["Strength"]

        p.ability_data["South Pole"]["Usetimer"]-=p.ability_data["South Pole"]["Usetimer"]!=0
    for i in enemies:
        if not levelup_overlay:
            i.think()
            i.move()
            i.draw()
    p.move()
    p.draw()
    for i in bullets:
        i.move()                        
        i.draw()
    for i in particles:
        i.animate()
    pygame.draw.rect(win,(255,0,0),(10,0,10,p.hp))
    if p.invincibility_frame>0:
        hurtscreen.set_alpha((1-p.hp/p.max_hp)*10*p.invincibility_frame)
        win.blit(hurtscreen,(0,0))
    g.blit(win,(0,0))
    if not keys[pygame.K_F5]:
        clock.tick(100)
    else:
        clock.tick(1)
    pygame.display.update()
pygame.quit()
