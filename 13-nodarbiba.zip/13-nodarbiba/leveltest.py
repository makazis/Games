from math import *
c=1.1
i=0
while c<1000000:
    c=ceil(c**(1+1/c*2))
    i+=1
print(i)
