from kscript import *
from Enemies.Enemy import *
type_colors=[
    (255,255,255),
    (0,255,0),
    (0,0,255),
    (255,255,0)
]
enemies=[]
class graph_point:
    def __init__(self,index):
        self.vertices=set()
        self.tips=choice((0,0,0,2,3))
        self.index=index
        if self.tips==2:
            enemies.append(Enemy("Goblin"))
            enemies[-1].position=self
        self.landmarks=[]
psi=0.2
point_count=randint(6,10)
line_count=point_count#min(croll(1+1/point_count),int(point_count**1.7))
points=[graph_point(i) for i in range(point_count)]
points[0].tips=1
position=points[1].index
shuffle(points)
for i in range(len(points)):
    points[i].vertices.add(points[(i+1)%len(points)].index)
    points[i].vertices.add(points[(i-1)%len(points)].index)
    
for i in range(line_count):
    point_alpha=randint(0,point_count-1)
    point_beta=randint(0,point_count-1)
    while point_beta==point_alpha:
        point_beta=randint(0,point_count-1)
    points[point_alpha].vertices.add(point_beta)
    if random()>psi:
        points[point_beta].vertices.add(point_alpha)
for i in points:
     i.vertices=list(i.vertices)
last_position=None
class Player:
    def __init__(self):
        self.hp=10
        self.max_hp=10
        self.AC=10
        self.level=0
        self.xp=0
        self.stats=[randint(1,20) for i in range(6)]
        self.astats=[(self.stats[i]-10)//2 for i in range(6)]
looked_at_enemy=0
current_enemies=[]
p=Player()
def next_turn(where):
    global position,last_position,current_enemies
    current_enemies=[]
    last_position=position
    position=points[position].vertices[where]
    for i in enemies:
        if i.moving:
            if i.grounding:
                if i.position==points[position]:
                    current_enemies.append(i)
                    break
                i.position=points[choice(i.position.vertices)]
                if points[position]==i.position:
                    current_enemies.append(i)
    #for i in current_enemies:
    #    i.act(p)
while run:
    exec(getevent())
    if keys[27]: run=False
    win.fill((23,3,3))
    pygame.draw.circle(win,type_colors[points[position].tips],(150,150),50,5)
    for i in range(len(points[position].vertices)):
        pygame.draw.circle(win,(255,255,255),(150+cos(tau/len(points[position].vertices)*i)*100,150+sin(tau/len(points[position].vertices)*i)*100),20,3)
        if last_position!=None:
            if last_position==points[position].vertices[i]:
                pygame.draw.circle(win,(255,255,255),(150+cos(tau/len(points[position].vertices)*i)*100,150+sin(tau/len(points[position].vertices)*i)*100),15,2)
        if not position in points[points[position].vertices[i]].vertices:
            pygame.draw.circle(win,(255,0,0),(150+cos(tau/len(points[position].vertices)*i)*100,150+sin(tau/len(points[position].vertices)*i)*100),10,2)
        if dist(mouse_pos,(150+cos(tau/len(points[position].vertices)*i)*100,150+sin(tau/len(points[position].vertices)*i)*100))<40:
            if click[0]:
                next_turn(i)
                break
    pygame.draw.rect(win,(0,0,0),(0,0,300,300),5)
    pygame.draw.rect(win,(0,0,0),(1500,0,300,300))
    if len(current_enemies)>0:
        center(render_text(current_enemies[looked_at_enemy].displayed_hp),win,1650,290)
    win.blit(render_text(f"Health: {p.hp}"),(305,5))
    endframe()
#for point in points:
#    print(point.index,point.tips,point.vertices)
pygame.quit()