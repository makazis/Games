from random import *
from math import *
import pygame
import os
import json
from kscript import croll
item_data={}
item_sprite_data={}
for root,dirs,files in os.walk(r"Enemies\\Items\\JSONS\\"):
    for file in files:
        if file.endswith(".json"):
            with open(os.path.join(root,file)) as F:
                item_data[file[:-5]]=(json.loads(F.read()))
        if file.endswith(".png"):
            item_sprite_data[file[:-4]]=pygame.image.load(os.path.join(root,file))
class Item:
    def __init__(self,tips):
        print(tips)
        self.tips=tips
        self.data=item_data[tips]
        self.type=self.data["Type"]
        if self.type=="Weapon":
            self.damage=self.data["Damage"]
            self.damage_type=self.damage[4]
            self.damage_calculation_function=lambda astats=[0,0,0,0,0,0]:astats[self.damage[3]]*(self.damage[3]>=0)+self.damage[2]+sum([randint(1,self.damage[1]) for i in range(self.damage[0])])
            self.bth=self.data["BTH"]
            self.bth_attribute=self.data["BTH Attribute"]
        self.quality=min(5,croll(3))
        self.sell_value=int(self.data["Sell Value"]*(1+random()+self.quality))
        self.buy_value=int(self.data["Buy Value"]*(1+random()+self.quality))
    def attack_with(self,attacker,defender):
        self.attack_roll=randint(1,20)+self.bth+attacker.astats[self.bth_attribute]*int(self.bth_attribute!=-1)
        if self.attack_roll>defender.AC:
            defender.hp-=self.damage_calculation_function(attacker.stats)
        else:
            return False
        return True
#Damage tag is counted as such:
# ammount of dice
# what dice
# additional bonus
# which stat to apply
# damage type(0: bludgeoning, 1: piercing, 2: Slashing)