import pygame
import json
import os
from math import *
from random import *
from Enemies.Items.Item import *
enemy_data={}
for root,dirs,files in os.walk(r"Enemies\\JSONS\\"):
    for file in files:
        if file.endswith(".json"):
            with open(os.path.join(root,file)) as F:
                enemy_data[file[:-5]]=(json.loads(F.read()))
        if file.endswith(".png"):
            enemy_data[file[:-4]]=pygame.image.load(os.path.join(root,file))
class Enemy:
    def __init__(self,tips):
        self.tips=tips
        self.stats=[randint(1,20) for i in range(6)]
        self.astats=[(self.stats[i]-10)//2 for i in range(6)]
        self.data=enemy_data[self.tips].copy()
        self.max_hp=(random()**self.data["Health"]["Normalizer"])*(randint(0,1)*2-1)*self.data["Health"]["Offset"]+self.data["Health"]["Middle"]
        self.hp=self.max_hp-random()*self.max_hp/2
        self.AC=self.data["AC"]
        self.gold=(random()**self.data["Cash"]["Normalizer"])*(randint(0,1)*2-1)*self.data["Cash"]["Offset"]+self.data["Cash"]["Middle"]
        self.speed=1
        self.moving="Walker" in self.data["AI"]
        self.grounding= "Grounding" in self.data["AI"]
        self.actions=[]
        self.action_weights=[]
        for i in self.data["Actions"]:
            self.actions.append(i)
            self.action_weights.append(i["Weight"])
        sum_action_weights=sum(self.action_weights)
        self.action_weights=[I/sum_action_weights for I in self.action_weights]
        self.inventory={
            "Weapons":[]
        }
        for I in self.data["Items"]:
            if random()<I["Chance"]:
                sum_ip_weights=sum(II["Weight"] for II in I["Item Pool"])
                ip_weights=[II["Weight"]/sum_ip_weights for II in I["Item Pool"]]
                item_roll=random()
                item_index_rolled=0
                for II in range(len(I["Item Pool"])):
                    if sum(ip_weights[:II+1]):
                        item_index_rolled=II
                        break
                item=Item(I["Item Pool"][item_index_rolled]["Item"])
                if item.type=="Weapon":
                    self.inventory["Weapons"].append(item)
        self.displayed_hp=self.check_hp()
    def check_hp(self):
        return ["Healthy","Bruised","Scarred","Damaged","Heavily Damaged","Almost Dead"][int((1-self.hp/self.max_hp)*6)]
    def act(self,p,friends=[]):
        action_log=[]
        self.action_roll=random()
        self.action=0
        for i in range(len(self.action_weights)):
            if sum(self.action_weights[:i+1])>self.action_roll:
                self.action=i
                break
        if self.actions[self.action]["Type"]=="Attack":
            action_log.append("tried to "+str(self.actions[self.action]["Name"])+" you.")
            self.attack_roll=randint(1,20)+self.data["BTH"]
        return action_log