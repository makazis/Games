from random import *
from math import *
import pygame
import Assets.Definition_Scripts.Element_Def as elemdef
pygame.init()
win=pygame.display.set_mode((2400,1200))
run=True
texts={}
fonts={}
def produce(text="TEXT NOT FOUND",size=20,color=(255,255,255),font="courier new"):
    font_key=str(size)+str(font)
    text_key=str(text)+str(size)+str(color)+str(font)
    if not font_key in fonts:
        fonts[font_key]=pygame.font.SysFont(font,int(size))
    if not text_key in texts:
        texts[text_key]=fonts[font_key].render(str(text),1,color)
    return texts[text_key]
def center(sprite,surface,x,y):
    sprite.set_colorkey((0,0,0))
    surface.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))
croll=lambda x:int(-log(random(),x))
click=[False,False,False]
ctimer=[0,0,0]
def checkevent():
    global run,keys,mouse_down,mouse_pos,click,ctimer,mouse_rel
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    mouse_pos=pygame.mouse.get_pos()
    mouse_down=pygame.mouse.get_pressed()
    ctimer=[(ctimer[i]+1)*mouse_down[i] for i in range(3)]
    click=[ctimer[i]==1 for i in range(3)]
    keys=pygame.key.get_pressed()
    mouse_rel=pygame.mouse.get_rel()
# Dimension, Connection sign, count
element_list=["H","O","C"]
connection_count=[
    [[0,1,1]],
    [[0,0,2]],
    [[0,-1,4]]
]
element_count=len(connection_count)
total_connections=[sum([i2[2] for i2 in connection_count[i]]) for i in range(element_count)]
blocked_element_sprites=[pygame.Surface((50,50)) for i in range(element_count)]
element_sprites=[pygame.Surface((50,50)) for i in range(element_count)]
for i in range(element_count):
    blocked_element_sprites[i].set_colorkey((0,0,0))
    element_sprites[i].set_colorkey((0,0,0))
    pygame.draw.rect(blocked_element_sprites[i],(25,25,25),(1,1,48,48),0,5)
    pygame.draw.rect(element_sprites[i],elemdef.element_colors[i],(1,1,48,48),0,5)
    center(produce(element_list[i],30,(55,55,55)),blocked_element_sprites[i],25,25)
    center(produce(element_list[i],30,(255,255,255)),element_sprites[i],25,25)
molecule_sheet=pygame.Surface((580,580))
class Particle:
    def __init__(self,tips):
        self.tips=tips
        self.total_connection_count=sum([i1[2] for i1 in connection_count[self.tips]])
        self.connections=[None for i in range(self.total_connection_count)]
class Creation:
    def __init__(self,energy_limit):
        self.energy_limit=energy_limit
        self.particles=[]
        self.stability=0
        self.mass=0
    def display_creation_screen(self):
        global run
        displaying_screen=True
        holding_element=-1
        molecule={0:
            {
                "Type":-1,
                "Pos":[0,0],
                "Connections":[],
                "All Connections":0
                }
        }
        relative_molecule_camera_x=0
        relative_molecule_camera_y=0
        maxmolkey=1
        next_removed=[]
        while run and displaying_screen:
            checkevent()
            win.fill((55,55,55))
            for i in range(element_count):
                xpos_of_element=i%10
                ypos_of_element=i//10
                if inventory[i]<1:
                    win.blit(blocked_element_sprites[i],(10+xpos_of_element*50,10+ypos_of_element*50))
                else:
                    win.blit(element_sprites[i],(10+xpos_of_element*50,10+ypos_of_element*50))
                    center(produce(inventory[i],18),win,20+xpos_of_element*50,20+ypos_of_element*50)
                    if 60+xpos_of_element*50>mouse_pos[0]>10+xpos_of_element*50 and 60+ypos_of_element*50>mouse_pos[1]>10+ypos_of_element*50:
                        if click[0]:
                            holding_element=i
                            inventory[i]-=1
            
            molecule_sheet.fill((5,5,25))
            mouse_on="Void"
            taken=False
            for which,i in enumerate(molecule):
                which=i
                i=molecule[i]
                i["All Connections"]=sum([i1[1] for i1 in i["Connections"]])
                for bond in i["Connections"]:
                    connection=bond[0]
                    connection_strength=bond[1]
                    if i["Type"]==-1 and molecule[connection]["Type"]==-1:
                        i["Connections"].remove(bond)
                        for i1 in enumerate(molecule[connection]["Connections"]):
                            if i1[1][0]==which:
                                molecule[connection]["Connections"].remove(i1[1])
                    else:
                        for i1 in range(connection_strength):
                            i1-=(connection_strength-1)/2
                            i1*=10
                            pygame.draw.line(molecule_sheet,(205,205,205),(i["Pos"][0]+1-relative_molecule_camera_x+290+i1,i["Pos"][1]+1-relative_molecule_camera_y+290+i1),
                                     (molecule[connection]["Pos"][0]+1-relative_molecule_camera_x+290+i1,molecule[connection]["Pos"][1]+1-relative_molecule_camera_y+290+i1),2)
            removed=next_removed.copy()
            next_removed=[]
            for which,i in enumerate(molecule):
                which=i
                i=molecule[i]
                if len(i["Connections"])==0 and which!=0:
                    #print(molecule)
                    removed.append(which)
            for i in removed:
                molecule.pop(i)
            for which,i in enumerate(molecule):
                which=i
                i=molecule[i]
                if i["Type"]==-1:
                    pygame.draw.rect(molecule_sheet,(35,35,35),(i["Pos"][0]+1-relative_molecule_camera_x+265,i["Pos"][1]+1-relative_molecule_camera_y+265,48,48),0,5)
                else:
                    molecule_sheet.blit(element_sprites[i["Type"]],(i["Pos"][0]+1-relative_molecule_camera_x+265,i["Pos"][1]+1-relative_molecule_camera_y+265))
                if abs(290+1810-relative_molecule_camera_x-mouse_pos[0]+i["Pos"][0])<25 and abs(290+10-relative_molecule_camera_y-mouse_pos[1]+i["Pos"][1])<25:
                    mouse_on="Molecule in sheet"
                    that_molecule=which
                    taken=i["Type"]>-1
            if mouse_on=="Void" and 1810<mouse_pos[0]<2390 and 10<mouse_pos[1]<590:
                if mouse_down[0] and holding_element==-1:
                    relative_molecule_camera_x-=mouse_rel[0]
                    relative_molecule_camera_y-=mouse_rel[1]
            elif mouse_on=="Molecule in sheet" and holding_element==-1:
                if mouse_down[0]:
                    if keys[pygame.K_SPACE]:
                        holding_element=molecule[that_molecule]["Type"]
                        molecule[that_molecule]["Type"]=-1
                    else:
                        molecule[that_molecule]["Pos"][0]+=mouse_rel[0]
                        molecule[that_molecule]["Pos"][1]+=mouse_rel[1]
                if molecule[that_molecule]["Type"]==-1 and that_molecule!=0:
                    if click[2]:
                        next_removed.append(that_molecule)
                        cons=molecule[that_molecule]["Connections"][0][0]
                        for i in enumerate(molecule[cons]["Connections"]):
                            if i[1][0]==that_molecule:
                                molecule[cons]["Connections"].remove(i[1])
                        for i in enumerate(molecule[cons]["Connections"]):
                            if molecule[i[1][0]]["Type"]==-1:
                                for i1 in enumerate(molecule[i[1][0]]["Connections"]):
                                    if i1[1][0]==cons:
                                        i1[1][1]+=1
                                        molecule[cons]["Connections"][i1[0]][1]+=1
                                        break
                                break
                        print(molecule)
            win.blit(molecule_sheet,(1810,10))
            if holding_element>-1:
                if ctimer[0]==0:
                    if mouse_on=="Void":
                        inventory[holding_element]+=1
                        holding_element=-1
                    elif mouse_on=="Molecule in sheet":
                        if taken:
                            inventory[holding_element]+=1
                            holding_element=-1
                        else: ### Creation of an element
                            molecule[that_molecule]["Type"]=holding_element
                            while molecule[that_molecule]["All Connections"]<total_connections[molecule[that_molecule]["Type"]]:
                                random_angle=tau*random()
                                molecule[maxmolkey]={
                                    "Type":-1,
                                    "Pos":[molecule[that_molecule]["Pos"][0]+cos(random_angle)*100,molecule[that_molecule]["Pos"][1]+sin(random_angle)*100],
                                    "Connections":[[that_molecule,1]]
                                }
                                molecule[that_molecule]["Connections"].append([maxmolkey,1])
                                molecule[that_molecule]["All Connections"]+=1
                                maxmolkey+=1
                            holding_element=-1
                else:
                    center(element_sprites[holding_element],win,mouse_pos[0],mouse_pos[1])
            
            pygame.display.update()
inventory=[0 for i in range(element_count)]
inventory[0]=6
inventory[1]=6
inventory[2]=6
C=Creation(100)
C.display_creation_screen()
while run:
    checkevent()
    win.fill((0,0,0))
    pygame.display.update()
pygame.quit()