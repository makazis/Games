from math import *
from random import *
import pygame
import json
import os


Pnames={}
for root, dirs, files in os.walk("Assets"):
    for file in files:
        if file.endswith('.json'):
            Pnames.update(json.loads(open(os.path.join(root,file),"r").read()))
for i in Pnames:
    brain=open("Assets\\Brains\\"+Pnames[i]["Brain"]+".py","r").read()
    exec(brain)
    Pnames[i]["Exist Function"]=exist
pygame.init()
win=pygame.display.set_mode((1800,900))
S=pygame.Surface((1800,900))
field=pygame.Surface((1800,900))
field.fill((25,105,25))
field.set_alpha(24)#23)
pygame.draw.line(field,(255,255,255),(900,0),(900,400),5)
pygame.draw.line(field,(255,255,255),(900,500),(900,900),5)

for i in range(9):
    i+=1
    pygame.draw.ellipse(field,((9-i)/8*255,255,(9-i)/8*255),(900-i*100,450-i*50,i*200,i*100),5)

pygame.draw.line(field,(255,255,255),(0,500),(0,400),5)
pygame.draw.line(field,(255,255,255),(1800,500),(1800,400),5)

run=True
clock=pygame.time.Clock()
drag=0.985#9
restitution=0.2
fonts={}
texts={}
def produce(font,size,text,color):
    global fonts,texts
    font_key=font+str(size)+text+str(color)
    if not font+str(size) in fonts:
        fonts[font+str(size)]=pygame.font.SysFont(font,size)
    if not font_key in texts:
        texts[font_key]=fonts[font+str(size)].render(text,1,color)
    return texts[font_key]
def center(sprite,surface,x,y):
    surface.blit(sprite,(x-sprite.get_width()/2,y-sprite.get_height()/2))
class ball:
    def __init__(self):
        self.radius=4
        self.mass=self.radius**2*pi/1000
        self.setup()
    def setup(self):
        self.x=900
        self.y=450
        self.xspeed=0
        self.yspeed=0
        self.vectors=[]
    def move(self):
        for i in self.vectors:
            self.xspeed+=i[0]
            self.yspeed+=i[1]
        self.vectors=[]
        self.xspeed*=drag
        self.yspeed*=drag
        while sqrt(self.xspeed**2+self.yspeed**2)>self.radius**2:
            self.xspeed*=drag
            self.yspeed*=drag
        self.y+=self.yspeed
        self.x+=self.xspeed
        self.x=min(max(0,self.x),1800)
        self.y=min(max(0,self.y),900)
        if self.x in [0,1800]: self.xspeed=-self.xspeed
        if self.y in [0,900]: self.yspeed=-self.yspeed
        if 500>self.y>400:
            if self.x==0:
                score_goal(0)
            elif self.x==1800:
                score_goal(1)
class Player:
    def __init__(self,name):
        self.name=name
        self.team=1
        print(self.name)
        self.Pnames=Pnames.copy()
        self.kick_power=Pnames[self.name]["Stats"]["Kick power"]
        self.leg_length=Pnames[self.name]["Stats"]["Leg length"]
        self.speed=Pnames[self.name]["Stats"]["Speed"]/50*(0.8+random()/5*2)
        self.size=Pnames[self.name]["Stats"]["Size"]/2
        self.exist=Pnames[self.name]["Exist Function"]
        self.offset=(random()-0.5)*random()*7
        self.mass=self.size**2*pi/1000
        self.setup()
    def setup(self):
        self.x=randint(0,900)
        self.y=randint(0,900)
        self.xspeed=0
        self.yspeed=0
        self.vectors=[]

        self.k_e=0
        self.kick_cooldown=0
    def move(self):
        for i in self.vectors:
            self.xspeed+=i[0]
            self.yspeed+=i[1]
        self.vectors=[]
        self.xspeed*=drag
        self.yspeed*=drag
        self.y+=self.yspeed
        self.x+=self.xspeed
        for i in team_1:
            if i!=self:
                dist=sqrt((self.x-i.x)**2+(self.y-i.y)**2)-self.size-i.size
                if dist<0:
                    angl=atan2(self.y-i.y,self.x-i.x)
                    self.x-=dist*cos(angl)
                    self.y-=dist*sin(angl)
        for i in team_2:
            if i!=self:
                dist=sqrt((self.x-i.x)**2+(self.y-i.y)**2)-self.size-i.size
                if dist<0:
                    angl=atan2(self.y-i.y,self.x-i.x)
                    self.x-=dist*cos(angl)
                    self.y-=dist*sin(angl)
        self.x=min(max(0,self.x),1800)
        self.y=min(max(0,self.y),900)
        if self.x in [0,1800]: self.xspeed=0
        if self.y in [0,900]: self.yspeed=0
    def kick(self,desired_angle):
        if self.kick_cooldown>0:
            self.kick_cooldown-=1
        else:
            for i in balls:
                if sqrt((self.x-i.x)**2+(self.y-i.y)**2)<self.size+self.leg_length+i.radius:
                    self.atack_angle=atan2(self.y-i.y,self.x-i.x)
                    kick_power=self.kick_power*(1+random()*3)/10
                    i.vectors.append([cos(self.atack_angle)*kick_power,-sin(self.atack_angle)*kick_power])
                    i.vectors.append([cos(desired_angle)*kick_power,sin(desired_angle)*kick_power])
                    #if -sin(self.atack_angle)-sin(desired_angle)*kick_power>0:
                    #    print("UP")
                    self.kick_cooldown=30
    def run(self,angle,speed=1):
        self.vectors.append([-cos(angle)*self.speed,-sin(angle)*self.speed])
def score_goal(team):
    global score
    score[team]+=1
    for i in balls:
        i.setup()
    for i in team_1:
        i.setup()
    for i in team_2:
        i.setup()
    for i in team_2:
        i.x+=900
score=[0,0]
balls=[ball()]
pnames=[i for i in Pnames]
team_1_names=[
    "Kazimirs" for i in range(10)
    
]
team_2_names=[
    "Juris" for i in range(1)
]
team_1=[Player(i) for i in team_1_names]
team_2=[Player(i) for i in team_2_names]
for i in team_2:
    i.x+=900
    i.team=2
vision_data={
    "Ball":balls[0],
    "Goal Alpha":(0,450),
    "Goal Beta":(1800,450),
    }
camera_focus=0
camera_player=0
camera_timer=0
camera_press_timer=0
camera_lengths=[1,len(team_1),len(team_2),1]
while run:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    S.blit(field,(0,0))
    keys=pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]: camera_press_timer+=1
    elif keys[pygame.K_LEFT]: camera_press_timer+=1
    else: camera_press_timer=0
    if camera_press_timer==1:
        if keys[pygame.K_RIGHT]:
            camera_player+=1
            if camera_player==camera_lengths[camera_focus]:
                camera_focus=(camera_focus+1)%4
                camera_player=0
        else:
            camera_player-=1
            if camera_player==-1:
                camera_focus=(camera_focus-1)%4
                camera_player=camera_lengths[camera_focus]-1
    center(produce("courier new",30,str(score[0]),(255,255,0)),S,1700,100)
    center(produce("courier new",30,str(score[1]),(0,255,255)),S,100,100)
    
    for i in team_1:
        i.exist(i,**vision_data)
        i.move()
        pygame.draw.circle(S,(0,125,255),(i.x,i.y),i.size)
    for i in enumerate(team_2):
        i[1].exist(i[1],**vision_data)
        i[1].move()
        pygame.draw.circle(S,(255,125,0),(i[1].x,i[1].y),i[1].size)
    for i in balls:
        i.move()
        pygame.draw.circle(S,(155,155,155),(i.x,i.y),i.radius)
    if camera_focus==0:
        win.blit(S,(0,0))
    elif camera_focus==1:
        win.blit(pygame.transform.scale(S.subsurface(max(0,min(1200,team_1[camera_player].x-300)),max(0,min(600,team_1[camera_player].y-150)),600,300),(1800,900)),(0,0))
    elif camera_focus==2:
        win.blit(pygame.transform.scale(S.subsurface(max(0,min(1200,team_2[camera_player].x-300)),max(0,min(600,team_2[camera_player].y-150)),600,300),(1800,900)),(0,0))
    elif camera_focus==3:
        win.blit(pygame.transform.scale(S.subsurface(max(0,min(1200,balls[0].x-300)),max(0,min(600,balls[0].y-150)),600,300),(1800,900)),(0,0))
    
    clock.tick(100)
    pygame.display.update()
pygame.quit()
