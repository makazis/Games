from math import *
from random import *
X=0
def exist(self,**vision):
    try:
        self.role_timer+=0
        self.role+=""
        self.random_timer+=random()*(randint(0,1)*2-1)
    except:
        self.role_timer=0
        self.role="attack"
        self.random_timer=0
    ball=vision["Ball"]
    self.perfect_angle=atan2(450-ball.y,vision["Goal "+["Beta","Alpha"][self.team-1]][0]-ball.x)
    self.direct_angle=atan2(self.y-ball.y,self.x-ball.x)+self.Pnames[self.name]["Attributes"]["Offset"]*random()*(randint(0,1)*2-1)
    distance_from_ball=sqrt((self.x-ball.x)**2+(self.y-ball.y)**2)
    if 50<self.x<1750 and 50<self.y<850:
        self.run(self.direct_angle+self.random_timer*(distance_from_ball>self.Pnames[self.name]["Attributes"]["Tolerance"])/10)
    else:
        self.run(self.direct_angle)
    self.kick(self.perfect_angle)
    """
    if self.team==1:
        if ball.x<=900:
            self.role="defense"
            self.role_timer=0
        elif ball.x>=900:
            self.role_timer+=1
            if self.role_timer==1:
                self.role=["attack","defense"][random()>Pnames[self.name]["Attributes"]["AD"]]
    if self.role=="defense":
        self.perfect_angle=atan2(450-ball.y,vision["Goal "+["Alpha","Beta"][self.team-1]][0]-ball.x)
        self.run_angle=-atan2(450-self.y,vision["Goal "+["Alpha","Beta"][self.team==1]][0]-self.x)
        self.run(self.run_angle)
        self.kick(self.perfect_angle)
    else:
        self.perfect_angle=atan2(450-ball.y,vision["Goal "+["Alpha","Beta"][self.team-1]][0]-ball.x)
        self.direct_angle=atan2(self.y-ball.y,self.x-ball.x)
        self.run(self.direct_angle)
        self.kick(self.perfect_angle)
    """
